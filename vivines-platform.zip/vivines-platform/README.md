# Vivines International — Online Aviation & Hospitality Certification Platform

**Success Meets Here**

A complete, production-ready client-server web application for Vivines International's online self-learning certification programme in Aviation & Hospitality Management, built for [Prof. Yogesh Vyavahare](mailto:hr.vivines@gmail.com).

- **Stack:** Node.js + Express backend, a JSON-file database with atomic writes, and a vanilla HTML/CSS/JS front end (no build step required).
- **Content:** 63 units across 13 categories, 441 questions (7 per unit) tagged by Bloom's Taxonomy, each with 150–350 words of study material.
- **Economy:** The "Wings" token system — 10 Wings on signup, modules and certificates priced in Wings.
- **Integrity:** Certificates are issued only after every unit assessment in a category is genuinely passed, and only server-side — correct answers are never sent to the browser.
- **Zero-config by default:** `npm install && npm start` runs the whole platform locally with no setup. Email and Google Drive backup are optional and degrade gracefully when unconfigured.

---

## 1. Quick start (local)

```bash
npm install
npm start
```

Then open **http://localhost:3000**.

On first run, the server auto-generates:
- A JWT signing secret
- An **admin passcode**, printed to the console and saved to `server/data/secrets.json`

Use that passcode to log in at **http://localhost:3000/admin.html**.

> ⚠️ `server/data/secrets.json` is gitignored on purpose — never commit it. Treat the admin passcode like a password.

---

## 2. Project structure

```
vivines-platform/
├── server/
│   ├── server.js              # Express app entry point
│   ├── secrets.js             # Auto-generates JWT secret + admin passcode
│   ├── db.js                  # JSON-file "database" with atomic writes
│   ├── middleware/auth.js     # JWT auth guards (learner + admin)
│   ├── routes/                # auth, units, quiz, wings, certificates,
│   │                          # consultations, jobs, admin
│   ├── utils/                 # email, driveBackup, certificate (PDF), helpers
│   └── data/
│       ├── content.js         # The full 63-unit / 441-question syllabus
│       ├── translations.js    # English / Marathi UI strings
│       ├── jobRoles.js        # Seed data for the Career Opportunities board
│       ├── db.json            # Generated at runtime (gitignored)
│       ├── secrets.json       # Generated at runtime (gitignored)
│       ├── uploads/           # Learner photos (gitignored)
│       └── certificates/      # Generated certificate PDFs (gitignored)
└── public/
    ├── index.html, login.html, register.html, dashboard.html,
    │   certificates.html, careers.html, consultation.html, admin.html
    ├── css/style.css
    ├── js/api.js               # fetch wrapper — every backend call goes through here
    ├── js/app.js                # all rendering/UI logic, page-routed by <body data-page="…">
    └── assets/vivines-logo.svg  # placeholder logo — see "Branding assets" below
```

---

## 3. How the Wings economy works

| Action | Cost |
|---|---|
| Sign up | **+10 Wings** (starting balance) |
| Unlock a unit | 3–5 Wings depending on category (Capstone: 20) |
| Claim a category certificate | 10–20 Wings depending on category |
| Claim the Full Programme master certificate | 40 Wings |
| First consultation session | Free |
| Each subsequent consultation session | 8 Wings |
| Soft Skills & Employability units | 15 Wings each (standalone track, priced independently) |

Every Wings movement is recorded in an immutable ledger (`db.transactions`) with a reason, timestamp, and resulting balance — visible to admins under **Fees & Transactions**, and to each learner under their own account. Admins can manually credit/debit a learner's balance from the learner detail view (e.g. to comp a promotional bonus), and every adjustment is logged the same way.

To change any pricing, edit `MODULE_GROUP_PRICING` and `CERTIFICATE_PRICING` at the top of `server/data/content.js`.

---

## 4. Certificates

- A category certificate becomes claimable only once **every unit in that category** is in the learner's `completedUnits` list (i.e. they scored ≥5/7 on every unit's assessment).
- Claiming spends Wings, then generates a PDF server-side with the learner's name, category, issue date, and their registered passport photo, via `server/utils/certificate.js` (using `pdfkit`).
- The PDF is stored under `server/data/certificates/` and is only ever served through the authenticated `/api/certificates/:id/download` route — never as a static file — so one learner can never fetch another's certificate.

### Branding assets
The real Vivines International logo is already in place at `public/assets/vivines-logo.png` (background removed) and `public/assets/favicon.png` (the mark cropped to a square favicon) — both are used automatically in the navbar and on every certificate PDF. If the logo is ever updated, just replace `public/assets/vivines-logo.png` with the new file (keep the transparent background) — the navbar chip and certificate header both reference that one file, so no code changes are needed for a like-for-like swap. If the new file has a different aspect ratio, adjust the `logoWidth`/`logoHeight` calculation in `server/utils/certificate.js`'s `generateCertificatePdf()`.

---

## 5. Email setup (optional)

Without any configuration, "emails" (welcome message, certificate-issued notice, consultation confirmation) are simply logged to the server console — the platform is fully functional either way.

To send real email, copy `.env.example` to `.env` and fill in SMTP credentials:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-address@gmail.com
SMTP_PASS=your-app-password       # use a Gmail "App Password", not your normal password
SMTP_FROM="Vivines International <your-address@gmail.com>"
```

Any standard SMTP provider works — Gmail, Zoho, SendGrid, Mailgun, or your own institute mail server.

---

## 6. Google Drive backup (optional)

Adds an automatic off-server backup of `server/data/db.json` every few minutes whenever data changes. Fully optional — the platform works perfectly without it.

1. In [Google Cloud Console](https://console.cloud.google.com/), create a project (or use an existing one) and enable the **Google Drive API**.
2. Create a **Service Account**, then create a JSON key for it and download it.
3. Save that key as `server/data/service-account.json` (this path is gitignored).
4. In Google Drive, create a backup folder and **share it** with the service account's email address (found inside the JSON key file, looks like `xxxx@xxxx.iam.gserviceaccount.com`) with Editor access.
5. Copy that folder's ID from its Drive URL into `.env`:
   ```
   GOOGLE_DRIVE_BACKUP_FOLDER_ID=your-folder-id-here
   ```
6. Run `npm install googleapis` (it's an optional dependency, not installed by default) — then restart the server.

---

## 7. Deployment

This is a standard Node.js/Express app — it needs a host that runs Node, **not** static hosting like GitHub Pages.

### Render / Railway / Fly.io (recommended for a small institute)
1. Push this repository to GitHub.
2. Create a new Web Service on [Render](https://render.com), [Railway](https://railway.app), or [Fly.io](https://fly.io), pointing at the repo.
3. Build command: `npm install`. Start command: `npm start`.
4. Add any `.env` variables you want (SMTP, Drive backup) in the platform's environment-variable settings.
5. **Important:** these platforms often use ephemeral or resettable filesystems on their free tiers — `server/data/db.json`, uploaded photos, and generated certificates can be wiped on redeploy. For a production institute deployment, either:
   - Use a paid tier with a **persistent disk/volume** mounted at `server/data/`, or
   - Enable the optional Google Drive backup (§6) as an off-server safety net, or
   - Migrate `db.js` to a real database (Postgres/MongoDB) — see §9 below.

### A VPS (DigitalOcean, AWS EC2, etc.) — most control
1. Install Node.js 18+ and `git` on the server.
2. Clone the repo, run `npm install`, copy `.env.example` to `.env` and configure it.
3. Run the app with a process manager so it survives reboots/crashes:
   ```bash
   npm install -g pm2
   pm2 start server/server.js --name vivines
   pm2 save
   pm2 startup
   ```
4. Put Nginx (or Caddy) in front as a reverse proxy for your custom domain + free HTTPS via Let's Encrypt / Caddy's automatic TLS.
5. Since `server/data/` lives on the VPS's real disk, it persists naturally — just make sure you have your own backup routine (a simple cron job copying `server/data/db.json` off-box is sufficient) in addition to, or instead of, the optional Drive backup.

### Custom domain
Once deployed, point your domain's DNS at the host (an A record to a VPS's IP, or a CNAME per Render/Railway/Fly's instructions), then configure the domain in that platform's dashboard.

---

## 8. Security notes

- Passwords are hashed with `bcryptjs` (10 salt rounds) — never stored in plaintext.
- Learner sessions are JWTs signed with a server-generated secret, expiring after 30 days; admin sessions expire after 12 hours.
- Quiz correct answers live only in `server/data/content.js` on the server and are stripped before any unit content is sent to the browser — grading happens entirely server-side in `routes/quiz.js`.
- Certificate PDFs are served through an authenticated, learner-scoped route, not as static files.
- Uploaded photos are size-limited (5MB) and type-checked (JPG/PNG/WEBP only).

## 9. Scaling beyond a JSON file

The `server/db.js` module is intentionally simple (a single JSON file with atomic, queued writes) so the platform needs **zero external infrastructure** to run. This comfortably handles a single-institute scale (hundreds to low thousands of learners). If Vivines International's learner base grows well beyond that, the natural next step is swapping `db.js`'s `readDb`/`mutate` functions for a real database client (e.g. Postgres via `pg`, or MongoDB via `mongodb`) — every route file calls only `readDb()`/`mutate()`/`nextId()`, so the storage layer is isolated behind those three functions and the rest of the app doesn't need to change.

---

## 10. Support

Vivines International — WhatsApp: +91 9665556735 / +91 9665556835 · Email: hr.vivines@gmail.com
