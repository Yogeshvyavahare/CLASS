// public/js/api.js
// Thin fetch wrapper. Every function returns a parsed JSON body and throws
// an Error with a human-readable message on failure, so callers in app.js
// can just try/catch and show err.message to the user.

const API_BASE = '/api';

function getToken() { return localStorage.getItem('vivines_token'); }
function getAdminToken() { return localStorage.getItem('vivines_admin_token'); }
function setToken(t) { localStorage.setItem('vivines_token', t); }
function setAdminToken(t) { localStorage.setItem('vivines_admin_token', t); }
function clearToken() { localStorage.removeItem('vivines_token'); localStorage.removeItem('vivines_user'); }
function clearAdminToken() { localStorage.removeItem('vivines_admin_token'); }

function getCachedUser() {
  try { return JSON.parse(localStorage.getItem('vivines_user') || 'null'); } catch (e) { return null; }
}
function setCachedUser(u) { localStorage.setItem('vivines_user', JSON.stringify(u)); }

async function apiRequest(path, { method = 'GET', body, isForm = false, admin = false } = {}) {
  const headers = {};
  const token = admin ? getAdminToken() : getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  let fetchBody = body;
  if (body && !isForm) {
    headers['Content-Type'] = 'application/json';
    fetchBody = JSON.stringify(body);
  }
  const res = await fetch(API_BASE + path, { method, headers, body: fetchBody });
  let data = null;
  try { data = await res.json(); } catch (e) { /* no JSON body, e.g. some 204s */ }
  if (!res.ok) {
    const message = (data && data.error) || `Request failed (${res.status})`;
    const err = new Error(message);
    err.status = res.status;
    throw err;
  }
  return data;
}

const Api = {
  // --- Auth ---
  register: (formData) => apiRequest('/auth/register', { method: 'POST', body: formData, isForm: true }),
  login: (email, password) => apiRequest('/auth/login', { method: 'POST', body: { email, password } }),
  adminLogin: (passcode) => apiRequest('/auth/admin-login', { method: 'POST', body: { passcode } }),
  me: () => apiRequest('/auth/me'),

  // --- i18n ---
  i18n: () => apiRequest('/i18n'),

  // --- Units ---
  listUnits: () => apiRequest('/units'),
  getUnit: (id) => apiRequest(`/units/${id}`),
  unlockUnit: (id) => apiRequest(`/units/${id}/unlock`, { method: 'POST' }),
  submitQuiz: (id, answers) => apiRequest(`/units/${id}/submit`, { method: 'POST', body: { answers } }),

  // --- Wings ---
  getWings: () => apiRequest('/wings'),

  // --- Certificates ---
  getCertificateEligibility: () => apiRequest('/certificates'),
  claimCertificate: (category) => apiRequest('/certificates/claim', { method: 'POST', body: { category } }),
  downloadCertificate: (id, suggestedName) => downloadBlob(`/certificates/${id}/download`, suggestedName, false),

  // --- Consultations ---
  getConsultations: () => apiRequest('/consultations'),
  requestConsultation: (payload) => apiRequest('/consultations', { method: 'POST', body: payload }),

  // --- Jobs ---
  getJobs: () => apiRequest('/jobs'),
  applyToJob: (id, coverMessage) => apiRequest(`/jobs/${id}/apply`, { method: 'POST', body: { coverMessage } }),

  // --- Admin ---
  adminStats: () => apiRequest('/admin/stats', { admin: true }),
  adminLearners: (q) => apiRequest(`/admin/learners${q ? '?q=' + encodeURIComponent(q) : ''}`, { admin: true }),
  adminLearnerDetail: (id) => apiRequest(`/admin/learners/${id}`, { admin: true }),
  adminUpdateLearner: (id, payload) => apiRequest(`/admin/learners/${id}`, { method: 'PATCH', body: payload, admin: true }),
  adminCertificates: () => apiRequest('/admin/certificates', { admin: true }),
  adminTransactions: () => apiRequest('/admin/transactions', { admin: true }),
  adminJobApplications: () => apiRequest('/admin/job-applications', { admin: true }),
  adminUpdateJobApplication: (id, status) => apiRequest(`/admin/job-applications/${id}`, { method: 'PATCH', body: { status }, admin: true }),
  adminConsultations: () => apiRequest('/admin/consultations', { admin: true }),
  adminUpdateConsultation: (id, status) => apiRequest(`/admin/consultations/${id}`, { method: 'PATCH', body: { status }, admin: true }),
  adminJobRoles: () => apiRequest('/admin/job-roles', { admin: true }),
  adminCreateJobRole: (payload) => apiRequest('/admin/job-roles', { method: 'POST', body: payload, admin: true }),
  adminUpdateJobRole: (id, payload) => apiRequest(`/admin/job-roles/${id}`, { method: 'PATCH', body: payload, admin: true }),
  adminDeleteJobRole: (id) => apiRequest(`/admin/job-roles/${id}`, { method: 'DELETE', admin: true }),
  adminDownloadCertificate: (id, suggestedName) => downloadBlob(`/admin/certificates/${id}/download`, suggestedName, true),
  adminGetLearnerPhotoBlobUrl: async (id) => {
    const res = await fetch(`${API_BASE}/admin/learners/${id}/photo`, { headers: { Authorization: `Bearer ${getAdminToken()}` } });
    if (!res.ok) throw new Error('No photo available.');
    const blob = await res.blob();
    return URL.createObjectURL(blob);
  }
};

// Fetches a binary file with the appropriate auth header and triggers a
// browser "Save As" download — needed because <a href> can't carry an
// Authorization header, and these endpoints are deliberately not public.
async function downloadBlob(path, suggestedName, admin) {
  const token = admin ? getAdminToken() : getToken();
  const res = await fetch(API_BASE + path, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) {
    let msg = `Download failed (${res.status})`;
    try { const j = await res.json(); if (j.error) msg = j.error; } catch (e) {}
    throw new Error(msg);
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = suggestedName || 'download.pdf';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
