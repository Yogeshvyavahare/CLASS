// public/js/app.js
// Shared rendering/UI logic for every page. Reads document.body.dataset.page
// to decide what to initialize. Talks to the backend exclusively through
// api.js (loaded before this file).

const PAGE = document.body.dataset.page;
const PUBLIC_PAGES = ['home', 'login', 'register'];

let I18N = null; // { en: {...}, mr: {...} }

function currentLang() { return localStorage.getItem('vivines_lang') || 'en'; }
function setLang(lang) { localStorage.setItem('vivines_lang', lang); }

function t(key) {
  const lang = currentLang();
  if (I18N && I18N[lang] && I18N[lang][key]) return I18N[lang][key];
  if (I18N && I18N.en && I18N.en[key]) return I18N.en[key];
  return key;
}

function applyI18nToDom() {
  document.body.dataset.lang = currentLang();
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    el.textContent = t(key);
  });
}

function escapeHtml(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function fmtDate(iso) {
  if (!iso) return '';
  try { return new Date(iso).toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' }); }
  catch (e) { return iso; }
}
function fmtDateTime(iso) {
  if (!iso) return '';
  try { return new Date(iso).toLocaleString('en-IN', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); }
  catch (e) { return iso; }
}

function showBanner(containerEl, message, type) {
  if (!containerEl) return;
  containerEl.innerHTML = `<div class="${type === 'success' ? 'success-banner' : 'error-banner'}">${escapeHtml(message)}</div>`;
}
function clearBanner(containerEl) { if (containerEl) containerEl.innerHTML = ''; }

// ---------- Header / Footer chrome ----------
function renderHeader() {
  const el = document.getElementById('site-header');
  if (!el) return;
  const isLoggedIn = !!getToken();
  const user = getCachedUser();
  const isAdminPage = PAGE === 'admin';

  const navLinksLoggedOut = `
    <a href="/index.html">${t('nav_home')}</a>
    <a href="/login.html">${t('nav_login')}</a>
    <a href="/register.html" class="btn btn-primary btn-sm" style="color:var(--navy);">${t('nav_register')}</a>
  `;
  const navLinksLoggedIn = `
    <a href="/dashboard.html">${t('nav_dashboard')}</a>
    <a href="/certificates.html">${t('nav_certificates')}</a>
    <a href="/careers.html">${t('nav_careers')}</a>
    <a href="/consultation.html">${t('nav_consult')}</a>
    <span class="wings-pill">✈ <span id="header-wings">${user ? user.wings : '—'}</span> ${t('wings_plural')}</span>
    <button class="nav-link" id="header-logout">${t('nav_logout')}</button>
  `;

  el.innerHTML = `
    <nav class="navbar">
      <div class="navbar-inner">
        <a href="/index.html" class="brand">
          <span class="logo-chip"><img src="/assets/vivines-logo.png" alt="Vivines International — Success Meets Here"></span>
        </a>
        <button class="mobile-menu-btn" id="mobile-menu-btn">☰</button>
        <div class="nav-links" id="nav-links">
          ${isAdminPage ? '<a href="/index.html">' + t('nav_home') + '</a>' : (isLoggedIn ? navLinksLoggedIn : navLinksLoggedOut)}
          <button class="lang-toggle" id="lang-toggle-btn">${t('lang_toggle')}</button>
          ${!isAdminPage ? `<a href="/admin.html" class="small" style="opacity:0.7;">${t('nav_admin')}</a>` : ''}
        </div>
      </div>
    </nav>
  `;

  document.getElementById('mobile-menu-btn')?.addEventListener('click', () => {
    document.getElementById('nav-links').classList.toggle('open');
  });
  document.getElementById('lang-toggle-btn')?.addEventListener('click', () => {
    setLang(currentLang() === 'en' ? 'mr' : 'en');
    applyI18nToDom();
    renderHeader();
  });
  document.getElementById('header-logout')?.addEventListener('click', () => {
    clearToken();
    window.location.href = '/index.html';
  });
}

function renderFooter() {
  const el = document.getElementById('site-footer');
  if (!el) return;
  el.innerHTML = `
    <footer class="footer">
      <div class="container footer-grid">
        <div>
          <strong style="color:#fff;">Vivines International</strong>
          <p class="small" style="max-width:320px;">${t('brand_tagline')} — Online Aviation &amp; Hospitality Certification Programme.</p>
        </div>
        <div>
          <strong style="color:#fff;">${t('footer_contact')}</strong>
          <p class="small">WhatsApp: +91 9665556735 / +91 9665556835<br>Email: <a href="mailto:hr.vivines@gmail.com">hr.vivines@gmail.com</a></p>
        </div>
      </div>
    </footer>
  `;
}

function refreshHeaderWings() {
  const user = getCachedUser();
  const span = document.getElementById('header-wings');
  if (span && user) span.textContent = user.wings;
}

// ---------- Auth guard ----------
function enforceAuthGuard() {
  const isLoggedIn = !!getToken();
  if (PAGE === 'admin') return; // admin has its own separate gate
  if (!PUBLIC_PAGES.includes(PAGE) && !isLoggedIn) {
    window.location.href = '/login.html';
    return true;
  }
  if ((PAGE === 'login' || PAGE === 'register') && isLoggedIn) {
    window.location.href = '/dashboard.html';
    return true;
  }
  return false;
}

// ---------- Boot ----------
(async function init() {
  try { I18N = await Api.i18n(); } catch (e) { I18N = { en: {}, mr: {} }; }

  const redirected = enforceAuthGuard();
  if (redirected) return;

  renderHeader();
  renderFooter();
  applyI18nToDom();

  const initFns = {
    home: initHomePage,
    login: initLoginPage,
    register: initRegisterPage,
    dashboard: initDashboardPage,
    certificates: initCertificatesPage,
    careers: initCareersPage,
    consultation: initConsultationPage,
    admin: initAdminPage
  };
  const fn = initFns[PAGE];
  if (fn) {
    try { await fn(); } catch (e) { console.error(`[${PAGE}] init failed`, e); }
  }
})();

function initHomePage() { /* static content — chrome + i18n already applied */ }

// ---------- Login page ----------
function initLoginPage() {
  const form = document.getElementById('login-form');
  const errorEl = document.getElementById('login-error');
  const submitBtn = document.getElementById('login-submit');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearBanner(errorEl);
    submitBtn.disabled = true;
    submitBtn.textContent = 'Logging in…';
    try {
      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;
      const { token, user } = await Api.login(email, password);
      setToken(token);
      setCachedUser(user);
      window.location.href = '/dashboard.html';
    } catch (err) {
      showBanner(errorEl, err.message, 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Log In';
    }
  });
}

// ---------- Register page ----------
function initRegisterPage() {
  const form = document.getElementById('register-form');
  const errorEl = document.getElementById('register-error');
  const submitBtn = document.getElementById('register-submit');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearBanner(errorEl);

    const photoInput = document.getElementById('reg-photo');
    if (!photoInput.files || photoInput.files.length === 0) {
      showBanner(errorEl, 'Please upload a passport-size photo.', 'error');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating account…';

    try {
      const fd = new FormData();
      fd.append('fullName', document.getElementById('reg-fullName').value.trim());
      fd.append('email', document.getElementById('reg-email').value.trim());
      fd.append('phone', document.getElementById('reg-phone').value.trim());
      fd.append('dob', document.getElementById('reg-dob').value);
      fd.append('password', document.getElementById('reg-password').value);
      fd.append('photo', photoInput.files[0]);

      const { token, user } = await Api.register(fd);
      setToken(token);
      setCachedUser(user);
      window.location.href = '/dashboard.html';
    } catch (err) {
      showBanner(errorEl, err.message, 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Create Account';
    }
  });
}

// ---------- Dashboard page ----------
function bloomBadgeClass(bloom) {
  if (!bloom) return 'badge-locked';
  if (bloom.startsWith('Foundation')) return 'badge-foundation';
  if (bloom.startsWith('Apply')) return 'badge-apply';
  if (bloom.startsWith('Analyze')) return 'badge-analyze';
  if (bloom.startsWith('Evaluate')) return 'badge-evaluate';
  return 'badge-locked';
}

let DASHBOARD_STATE = { grouped: {} };

async function initDashboardPage() {
  const user = getCachedUser();
  if (user) document.getElementById('welcome-name').textContent = `, ${user.fullName.split(' ')[0]}`;

  await loadDashboardUnits();
}

async function loadDashboardUnits() {
  const container = document.getElementById('units-container');
  try {
    const data = await Api.listUnits();
    DASHBOARD_STATE.grouped = data.grouped;
    renderStatRow(data.units);
    renderUnitsList(data.grouped);
  } catch (err) {
    container.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}

function renderStatRow(units) {
  const completed = units.filter(u => u.completed).length;
  const unlocked = units.filter(u => u.unlocked).length;
  const user = getCachedUser();
  document.getElementById('stat-row').innerHTML = `
    <div class="stat-box"><div class="stat-value">${user ? user.wings : '—'}</div><div class="stat-label">${t('wings_balance')}</div></div>
    <div class="stat-box"><div class="stat-value">${completed} / ${units.length}</div><div class="stat-label">Units Completed</div></div>
    <div class="stat-box"><div class="stat-value">${unlocked}</div><div class="stat-label">Units Unlocked</div></div>
  `;
}

function renderUnitsList(grouped) {
  const container = document.getElementById('units-container');
  const categories = Object.keys(grouped);
  if (categories.length === 0) {
    container.innerHTML = `<div class="empty-state">No modules published yet.</div>`;
    return;
  }
  container.innerHTML = categories.map(cat => {
    const units = grouped[cat];
    const doneCount = units.filter(u => u.completed).length;
    return `
      <div class="category-block">
        <h3 class="category-title">${escapeHtml(cat)} <span class="muted small">(${doneCount}/${units.length} completed)</span></h3>
        <div class="unit-list">
          ${units.map(u => renderUnitRow(u)).join('')}
        </div>
      </div>
    `;
  }).join('');

  container.querySelectorAll('[data-open-unit]').forEach(el => {
    el.addEventListener('click', () => openUnitModal(el.getAttribute('data-open-unit')));
  });
}

function renderUnitRow(u) {
  let statusBadge = '';
  if (u.completed) statusBadge = `<span class="badge badge-completed">${t('module_completed')}</span>`;
  else if (u.unlocked) statusBadge = `<span class="badge badge-apply">In Progress</span>`;
  else statusBadge = `<span class="badge badge-locked">${t('module_locked')}</span>`;

  const actionLabel = u.completed ? 'Review' : (u.unlocked ? t('module_continue') : `${t('module_start')} — ${u.wingsCost} ✈`);

  return `
    <div class="unit-row">
      <div>
        <div class="unit-title">${escapeHtml(u.title)}</div>
        <div class="unit-meta">${u.questionCount} questions${u.attempts ? ` · ${u.attempts} attempt${u.attempts === 1 ? '' : 's'}` : ''}</div>
      </div>
      <div class="flex gap-2 items-center">
        ${statusBadge}
        <button class="btn btn-secondary btn-sm" data-open-unit="${u.id}">${actionLabel}</button>
      </div>
    </div>
  `;
}

// ---------- Unit modal: study material + TTS + quiz ----------
let CURRENT_UNIT_ANSWERS = {};

async function openUnitModal(unitId) {
  const root = document.getElementById('unit-modal-root');

  // Find summary first to know lock state without another round trip
  let summary = null;
  Object.values(DASHBOARD_STATE.grouped).forEach(list => {
    const found = list.find(u => u.id === unitId);
    if (found) summary = found;
  });

  if (summary && !summary.unlocked) {
    root.innerHTML = renderModalShell(`
      <h2 style="margin-top:0;color:var(--navy);">${escapeHtml(summary.title)}</h2>
      <p class="muted">This module is locked. Unlock it to access the study material and assessment.</p>
      <div class="error-banner hidden" id="unlock-error"></div>
      <button class="btn btn-primary" id="unlock-btn">Unlock for ${summary.wingsCost} ✈ ${t('wings_plural')}</button>
    `);
    bindModalClose();
    document.getElementById('unlock-btn').addEventListener('click', async () => {
      const btn = document.getElementById('unlock-btn');
      const errEl = document.getElementById('unlock-error');
      btn.disabled = true; btn.textContent = 'Unlocking…';
      try {
        const result = await Api.unlockUnit(unitId);
        if (result.user) { setCachedUser(result.user); refreshHeaderWings(); }
        await loadDashboardUnits();
        openUnitModal(unitId);
      } catch (err) {
        errEl.textContent = err.message;
        errEl.classList.remove('hidden');
        btn.disabled = false;
        btn.textContent = `Unlock for ${summary.wingsCost} ✈ ${t('wings_plural')}`;
      }
    });
    return;
  }

  root.innerHTML = renderModalShell('<div class="spinner"></div>');
  bindModalClose();

  try {
    const unit = await Api.getUnit(unitId);
    CURRENT_UNIT_ANSWERS = {};
    renderUnitContent(unit);
  } catch (err) {
    document.getElementById('unit-modal-body').innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}

function renderModalShell(innerHtml) {
  return `
    <div class="modal-overlay" id="unit-modal-overlay">
      <div class="modal-box">
        <button class="modal-close" id="unit-modal-close-btn">&times;</button>
        <div id="unit-modal-body">${innerHtml}</div>
      </div>
    </div>
  `;
}

function bindModalClose() {
  document.getElementById('unit-modal-close-btn')?.addEventListener('click', closeUnitModal);
  document.getElementById('unit-modal-overlay')?.addEventListener('click', (e) => {
    if (e.target.id === 'unit-modal-overlay') closeUnitModal();
  });
}

function closeUnitModal() {
  window.speechSynthesis?.cancel();
  document.getElementById('unit-modal-root').innerHTML = '';
}

function renderUnitContent(unit) {
  const body = document.getElementById('unit-modal-body');
  const lastAttempt = unit.attempts && unit.attempts.length ? unit.attempts[unit.attempts.length - 1] : null;

  body.innerHTML = `
    <h2 style="margin-top:0;color:var(--navy);">${escapeHtml(unit.title)}</h2>
    <p class="muted small mt-0">${escapeHtml(unit.category)}</p>

    <div class="tts-bar">
      <button class="btn btn-outline btn-sm" style="color:var(--navy);border-color:var(--navy);" id="tts-play-btn">▶ Play</button>
      <button class="btn btn-outline btn-sm hidden" style="color:var(--navy);border-color:var(--navy);" id="tts-stop-btn">■ Stop</button>
      <span class="tts-label">${t('audio_label')}</span>
    </div>

    <p class="study-text">${escapeHtml(unit.studyMaterial)}</p>

    ${unit.completed ? `<div class="quiz-result pass">${t('quiz_passed')} (${lastAttempt.score}/${lastAttempt.total})</div>` : ''}

    <h3 style="color:var(--navy);">${t('quiz_submit') === 'Submit Answers' ? 'Assessment' : 'Assessment'}</h3>
    <form id="quiz-form">
      ${unit.questions.map((q, idx) => renderQuestionBlock(q, idx)).join('')}
      <div id="quiz-error"></div>
      <button type="submit" class="btn btn-primary" id="quiz-submit-btn">${unit.completed ? t('quiz_retake') : t('quiz_submit')}</button>
    </form>
    <div id="quiz-result-area"></div>
  `;

  // TTS
  const playBtn = document.getElementById('tts-play-btn');
  const stopBtn = document.getElementById('tts-stop-btn');
  playBtn.addEventListener('click', () => {
    if (!('speechSynthesis' in window)) {
      alert('Audio narration is not supported in this browser.');
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(unit.studyMaterial);
    utterance.rate = 0.98;
    utterance.onend = () => { playBtn.classList.remove('hidden'); stopBtn.classList.add('hidden'); };
    window.speechSynthesis.speak(utterance);
    playBtn.classList.add('hidden');
    stopBtn.classList.remove('hidden');
  });
  stopBtn.addEventListener('click', () => {
    window.speechSynthesis.cancel();
    playBtn.classList.remove('hidden');
    stopBtn.classList.add('hidden');
  });

  // Option selection
  body.querySelectorAll('.option-row').forEach(row => {
    row.addEventListener('click', () => {
      const qId = row.getAttribute('data-question');
      const optIdx = row.getAttribute('data-option');
      CURRENT_UNIT_ANSWERS[qId] = Number(optIdx);
      body.querySelectorAll(`.option-row[data-question="${qId}"]`).forEach(r => r.classList.remove('selected'));
      row.classList.add('selected');
      const input = row.querySelector('input');
      if (input) input.checked = true;
    });
  });

  document.getElementById('quiz-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errEl = document.getElementById('quiz-error');
    clearBanner(errEl);

    if (Object.keys(CURRENT_UNIT_ANSWERS).length < unit.questions.length) {
      showBanner(errEl, 'Please answer every question before submitting.', 'error');
      return;
    }

    const btn = document.getElementById('quiz-submit-btn');
    btn.disabled = true;
    btn.textContent = 'Grading…';

    try {
      const result = await Api.submitQuiz(unit.id, CURRENT_UNIT_ANSWERS);
      const resultArea = document.getElementById('quiz-result-area');
      resultArea.innerHTML = `
        <div class="quiz-result ${result.passed ? 'pass' : 'fail'}">
          <strong>${result.score} / ${result.total}</strong><br>
          ${result.passed ? t('quiz_passed') : t('quiz_failed')}
        </div>
      `;
      btn.textContent = result.passed ? t('quiz_retake') : 'Try Again';
      btn.disabled = false;
      await loadDashboardUnits();
    } catch (err) {
      showBanner(errEl, err.message, 'error');
      btn.disabled = false;
      btn.textContent = t('quiz_submit');
    }
  });
}

function renderQuestionBlock(q, idx) {
  return `
    <div class="question-block">
      <div class="flex justify-between items-center">
        <div class="question-text">${idx + 1}. ${escapeHtml(q.text)}</div>
        <span class="badge ${bloomBadgeClass(q.bloom)}">${escapeHtml(q.bloom)}</span>
      </div>
      ${q.options.map((opt, oIdx) => `
        <label class="option-row" data-question="${q.id}" data-option="${oIdx}">
          <input type="radio" name="${q.id}" value="${oIdx}">
          <span>${escapeHtml(opt)}</span>
        </label>
      `).join('')}
    </div>
  `;
}

// ---------- Certificates page ----------
async function initCertificatesPage() {
  const container = document.getElementById('cert-container');
  const claimedContainer = document.getElementById('claimed-container');
  const errorEl = document.getElementById('cert-error');

  async function reload() {
    try {
      const data = await Api.getCertificateEligibility();
      renderEligibility(data.eligibility, container, errorEl);
      renderClaimed(data.certificates, claimedContainer);
    } catch (err) {
      container.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
    }
  }

  function renderEligibility(list, el) {
    el.innerHTML = `<div class="grid grid-2">${list.map(item => {
      const label = item.label || item.category;
      let action;
      if (item.claimed) {
        action = `<span class="badge badge-completed">Claimed</span>`;
      } else if (item.complete) {
        action = `<button class="btn btn-primary btn-sm" data-claim="${escapeHtml(item.category)}">${t('cert_claim')} — ${item.wingsCost} ✈</button>`;
      } else {
        action = `<span class="badge badge-locked">Not yet complete</span>`;
      }
      return `
        <div class="card">
          <h4 style="margin:0 0 8px;color:var(--navy);">${escapeHtml(label)}</h4>
          ${action}
        </div>
      `;
    }).join('')}</div>`;

    el.querySelectorAll('[data-claim]').forEach(btn => {
      btn.addEventListener('click', async () => {
        clearBanner(errorEl);
        btn.disabled = true;
        btn.textContent = 'Claiming…';
        try {
          const result = await Api.claimCertificate(btn.getAttribute('data-claim'));
          if (result.user) { setCachedUser(result.user); refreshHeaderWings(); }
          await reload();
        } catch (err) {
          showBanner(errorEl, err.message, 'error');
          btn.disabled = false;
          btn.textContent = t('cert_claim');
        }
      });
    });
  }

  function renderClaimed(certs, el) {
    if (!certs || certs.length === 0) {
      el.innerHTML = `<div class="empty-state">No certificates claimed yet.</div>`;
      return;
    }
    el.innerHTML = `<div class="unit-list">${certs.map(c => `
      <div class="unit-row">
        <div>
          <div class="unit-title">${escapeHtml(c.label)}</div>
          <div class="unit-meta">Issued ${fmtDate(c.issuedAt)}</div>
        </div>
        <button class="btn btn-secondary btn-sm" data-download="${c.id}">Download PDF</button>
      </div>
    `).join('')}</div>`;

    el.querySelectorAll('[data-download]').forEach(btn => {
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        try {
          await Api.downloadCertificate(btn.getAttribute('data-download'), 'Vivines-Certificate.pdf');
        } catch (err) {
          alert(err.message);
        }
        btn.disabled = false;
      });
    });
  }

  await reload();
}

// ---------- Careers page ----------
async function initCareersPage() {
  const container = document.getElementById('careers-container');
  try {
    const data = await Api.getJobs();
    if (!data.unlocked) {
      container.innerHTML = `<div class="empty-state">🔒 ${escapeHtml(data.message)}</div>`;
      return;
    }
    if (data.roles.length === 0) {
      container.innerHTML = `<div class="empty-state">No open roles right now — check back soon.</div>`;
      return;
    }
    const appliedIds = new Set((data.myApplications || []).map(a => a.roleId));
    container.innerHTML = `<div class="grid grid-2">${data.roles.map(r => `
      <div class="card">
        <h4 style="margin:0 0 4px;color:var(--navy);">${escapeHtml(r.title)}</h4>
        <p class="muted small mt-0">${escapeHtml(r.category)} · ${escapeHtml(r.location)}</p>
        <p class="small">${escapeHtml(r.description)}</p>
        <p class="small muted"><strong>Requirements:</strong> ${escapeHtml(r.requirements)}</p>
        ${appliedIds.has(r.id)
          ? `<span class="badge badge-completed">Applied</span>`
          : `<button class="btn btn-primary btn-sm" data-apply="${r.id}">Apply</button>`}
      </div>
    `).join('')}</div>`;

    container.querySelectorAll('[data-apply]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const msg = prompt('Add a short note to your application (optional):') || '';
        btn.disabled = true;
        btn.textContent = 'Applying…';
        try {
          await Api.applyToJob(btn.getAttribute('data-apply'), msg);
          btn.outerHTML = `<span class="badge badge-completed">Applied</span>`;
        } catch (err) {
          alert(err.message);
          btn.disabled = false;
          btn.textContent = 'Apply';
        }
      });
    });
  } catch (err) {
    container.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}

// ---------- Consultation page ----------
async function initConsultationPage() {
  const form = document.getElementById('consult-form');
  const errorEl = document.getElementById('consult-error');
  const listEl = document.getElementById('my-consultations');
  const costNote = document.getElementById('consult-cost-note');

  async function reload() {
    try {
      const data = await Api.getConsultations();
      costNote.textContent = data.nextSessionCost === 0
        ? t('consult_free_note')
        : `${t('consult_paid_note')} (${data.nextSessionCost} ✈ ${t('wings_plural')})`;

      if (!data.consultations.length) {
        listEl.innerHTML = `<p class="muted small">No requests yet.</p>`;
        return;
      }
      listEl.innerHTML = data.consultations.map(c => `
        <div class="unit-row">
          <div>
            <div class="unit-title">${escapeHtml(c.topic)}</div>
            <div class="unit-meta">${fmtDateTime(c.requestedAt)} · ${c.isFree ? 'Free session' : c.wingsCost + ' ✈'}</div>
          </div>
          <span class="status-pill badge-${c.status === 'completed' ? 'completed' : 'apply'}">${escapeHtml(c.status)}</span>
        </div>
      `).join('');
    } catch (err) {
      listEl.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearBanner(errorEl);
    const btn = document.getElementById('consult-submit');
    btn.disabled = true;
    btn.textContent = 'Sending…';
    try {
      const result = await Api.requestConsultation({
        topic: document.getElementById('consult-topic').value.trim(),
        preferredTime: document.getElementById('consult-time').value.trim(),
        message: document.getElementById('consult-message').value.trim()
      });
      if (result.user) { setCachedUser(result.user); refreshHeaderWings(); }
      form.reset();
      await reload();
    } catch (err) {
      showBanner(errorEl, err.message, 'error');
    }
    btn.disabled = false;
    btn.textContent = 'Request Session';
  });

  await reload();
}

// ---------- Admin page ----------
let ADMIN_ACTIVE_TAB = 'learners';

async function initAdminPage() {
  const loginView = document.getElementById('admin-login-view');
  const panelView = document.getElementById('admin-panel-view');
  const loginForm = document.getElementById('admin-login-form');
  const loginError = document.getElementById('admin-login-error');

  function showPanel() {
    loginView.classList.add('hidden');
    panelView.classList.remove('hidden');
    loadAdminStats();
    switchAdminTab('learners');
  }
  function showLogin() {
    panelView.classList.add('hidden');
    loginView.classList.remove('hidden');
  }

  if (getAdminToken()) {
    showPanel();
  } else {
    showLogin();
  }

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearBanner(loginError);
    try {
      const { token } = await Api.adminLogin(document.getElementById('admin-passcode').value.trim());
      setAdminToken(token);
      showPanel();
    } catch (err) {
      showBanner(loginError, err.message, 'error');
    }
  });

  document.getElementById('admin-logout-btn').addEventListener('click', () => {
    clearAdminToken();
    showLogin();
  });

  document.querySelectorAll('.admin-tab').forEach(tabBtn => {
    tabBtn.addEventListener('click', () => switchAdminTab(tabBtn.getAttribute('data-tab')));
  });
}

async function loadAdminStats() {
  try {
    const stats = await Api.adminStats();
    document.getElementById('admin-stat-row').innerHTML = `
      <div class="stat-box"><div class="stat-value">${stats.totalLearners}</div><div class="stat-label">Total Learners</div></div>
      <div class="stat-box"><div class="stat-value">${stats.totalCertificatesIssued}</div><div class="stat-label">Certificates Issued</div></div>
      <div class="stat-box"><div class="stat-value">${stats.totalWingsInCirculation}</div><div class="stat-label">Wings In Circulation</div></div>
      <div class="stat-box"><div class="stat-value">${stats.pendingConsultations}</div><div class="stat-label">Pending Consultations</div></div>
      <div class="stat-box"><div class="stat-value">${stats.totalJobApplications}</div><div class="stat-label">Job Applications</div></div>
    `;
  } catch (err) { console.error(err); }
}

function switchAdminTab(tabName) {
  ADMIN_ACTIVE_TAB = tabName;
  document.querySelectorAll('.admin-tab').forEach(b => b.classList.toggle('active', b.getAttribute('data-tab') === tabName));
  const renderers = {
    learners: renderAdminLearnersTab,
    certificates: renderAdminCertificatesTab,
    transactions: renderAdminTransactionsTab,
    applications: renderAdminApplicationsTab,
    consultations: renderAdminConsultationsTab,
    roles: renderAdminRolesTab
  };
  const content = document.getElementById('admin-tab-content');
  content.innerHTML = '<div class="spinner"></div>';
  renderers[tabName]?.(content);
}

// --- Learners tab ---
async function renderAdminLearnersTab(content) {
  try {
    const { learners } = await Api.adminLearners();
    content.innerHTML = `
      <div class="form-group" style="max-width:320px;">
        <input type="search" id="admin-learner-search" placeholder="Search by name or email…">
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Wings</th><th>Completed</th><th>Certs</th><th>Status</th><th></th></tr></thead>
          <tbody id="admin-learners-tbody"></tbody>
        </table>
      </div>
    `;
    const tbody = document.getElementById('admin-learners-tbody');

    function renderRows(list) {
      tbody.innerHTML = list.map(u => `
        <tr>
          <td>${escapeHtml(u.fullName)}</td>
          <td>${escapeHtml(u.email)}</td>
          <td>${u.wings}</td>
          <td>${u.unitsCompleted}</td>
          <td>${u.certificatesClaimed}</td>
          <td><span class="status-pill ${u.suspended ? 'badge-analyze' : 'badge-completed'}">${u.suspended ? 'Suspended' : 'Active'}</span></td>
          <td><button class="btn btn-secondary btn-sm" data-view-learner="${u.id}">View</button></td>
        </tr>
      `).join('');
      tbody.querySelectorAll('[data-view-learner]').forEach(btn => {
        btn.addEventListener('click', () => openLearnerDetailModal(btn.getAttribute('data-view-learner')));
      });
    }
    renderRows(learners);

    document.getElementById('admin-learner-search').addEventListener('input', async (e) => {
      const q = e.target.value.trim();
      const result = await Api.adminLearners(q);
      renderRows(result.learners);
    });
  } catch (err) {
    content.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}

async function openLearnerDetailModal(userId) {
  const root = document.getElementById('admin-modal-root');
  root.innerHTML = `<div class="modal-overlay" id="admin-modal-overlay"><div class="modal-box" style="max-width:820px;"><button class="modal-close" id="admin-modal-close">&times;</button><div id="admin-modal-body"><div class="spinner"></div></div></div></div>`;
  document.getElementById('admin-modal-close').addEventListener('click', () => root.innerHTML = '');
  document.getElementById('admin-modal-overlay').addEventListener('click', (e) => { if (e.target.id === 'admin-modal-overlay') root.innerHTML = ''; });

  try {
    const data = await Api.adminLearnerDetail(userId);
    const u = data.user;
    document.getElementById('admin-modal-body').innerHTML = `
      <h2 style="margin-top:0;color:var(--navy);">${escapeHtml(u.fullName)}</h2>
      <p class="muted small mt-0">${escapeHtml(u.email)} · ${escapeHtml(u.phone || 'No phone on file')} · DOB ${escapeHtml(u.dob)}</p>
      <div class="flex gap-2" style="margin-bottom:16px;flex-wrap:wrap;">
        <button class="btn btn-sm ${u.suspended ? 'btn-primary' : 'btn-danger'}" id="toggle-suspend-btn">${u.suspended ? 'Reinstate Account' : 'Suspend Account'}</button>
      </div>
      <div class="card" style="margin-bottom:16px;">
        <strong>Wings balance: ${u.wings}</strong>
        <div class="flex gap-2" style="margin-top:8px;">
          <input type="number" id="wings-adjust-amount" placeholder="+/- amount" style="width:120px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;">
          <input type="text" id="wings-adjust-reason" placeholder="Reason" style="flex:1;padding:6px 8px;border:1px solid var(--border);border-radius:6px;">
          <button class="btn btn-secondary btn-sm" id="wings-adjust-btn">Adjust</button>
        </div>
      </div>

      <h4 style="color:var(--navy);">Certificates (${data.certificates.length})</h4>
      ${data.certificates.length ? `<ul class="small">${data.certificates.map(c => `<li>${escapeHtml(c.label)} — ${fmtDate(c.issuedAt)} <button class="btn btn-secondary btn-sm" data-admin-download="${c.id}">Download</button></li>`).join('')}</ul>` : '<p class="muted small">None yet.</p>'}

      <h4 style="color:var(--navy);">Transactions (${data.transactions.length})</h4>
      ${data.transactions.length ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Balance</th><th>Reason</th></tr></thead><tbody>
        ${data.transactions.map(txn => `<tr><td>${fmtDateTime(txn.at)}</td><td>${txn.type}</td><td>${txn.amount}</td><td>${txn.balanceAfter}</td><td>${escapeHtml(txn.reason)}</td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted small">None yet.</p>'}

      <h4 style="color:var(--navy);">Job Applications (${data.applications.length})</h4>
      ${data.applications.length ? `<ul class="small">${data.applications.map(a => `<li>${escapeHtml(a.roleTitle)} — ${escapeHtml(a.status)} (${fmtDate(a.submittedAt)})</li>`).join('')}</ul>` : '<p class="muted small">None yet.</p>'}

      <h4 style="color:var(--navy);">Consultations (${data.consultations.length})</h4>
      ${data.consultations.length ? `<ul class="small">${data.consultations.map(c => `<li>${escapeHtml(c.topic)} — ${escapeHtml(c.status)} (${fmtDate(c.requestedAt)})</li>`).join('')}</ul>` : '<p class="muted small">None yet.</p>'}

      <h4 style="color:var(--navy);">Activity Log (${data.activity.length})</h4>
      <div style="max-height:180px;overflow-y:auto;">
        <ul class="small muted">${data.activity.map(l => `<li>${fmtDateTime(l.at)} — ${escapeHtml(l.action)} ${escapeHtml(l.detail)}</li>`).join('')}</ul>
      </div>
    `;

    document.getElementById('toggle-suspend-btn').addEventListener('click', async () => {
      await Api.adminUpdateLearner(userId, { suspended: !u.suspended });
      openLearnerDetailModal(userId);
      renderAdminLearnersTab(document.getElementById('admin-tab-content'));
    });

    document.getElementById('wings-adjust-btn').addEventListener('click', async () => {
      const amount = Number(document.getElementById('wings-adjust-amount').value);
      const reason = document.getElementById('wings-adjust-reason').value.trim();
      if (!amount) return alert('Enter a non-zero amount.');
      try {
        await Api.adminUpdateLearner(userId, { adjustWings: amount, adjustReason: reason });
        openLearnerDetailModal(userId);
      } catch (err) { alert(err.message); }
    });

    document.querySelectorAll('[data-admin-download]').forEach(btn => {
      btn.addEventListener('click', () => Api.adminDownloadCertificate(btn.getAttribute('data-admin-download'), 'Vivines-Certificate.pdf').catch(e => alert(e.message)));
    });
  } catch (err) {
    document.getElementById('admin-modal-body').innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}

// --- Certificates tab ---
async function renderAdminCertificatesTab(content) {
  try {
    const { certificates } = await Api.adminCertificates();
    if (!certificates.length) { content.innerHTML = '<div class="empty-state">No certificates issued yet.</div>'; return; }
    content.innerHTML = `<div class="table-wrap"><table><thead><tr><th>Learner</th><th>Certificate</th><th>Issued</th><th>Wings Cost</th><th></th></tr></thead><tbody>
      ${certificates.map(c => `<tr>
        <td>${escapeHtml(c.learnerName)}<br><span class="muted small">${escapeHtml(c.learnerEmail)}</span></td>
        <td>${escapeHtml(c.label)}</td>
        <td>${fmtDate(c.issuedAt)}</td>
        <td>${c.wingsCost}</td>
        <td><button class="btn btn-secondary btn-sm" data-dl="${c.id}">Download</button></td>
      </tr>`).join('')}
    </tbody></table></div>`;
    content.querySelectorAll('[data-dl]').forEach(btn => {
      btn.addEventListener('click', () => Api.adminDownloadCertificate(btn.getAttribute('data-dl'), 'Vivines-Certificate.pdf').catch(e => alert(e.message)));
    });
  } catch (err) {
    content.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}

// --- Transactions tab ---
async function renderAdminTransactionsTab(content) {
  try {
    const { transactions } = await Api.adminTransactions();
    if (!transactions.length) { content.innerHTML = '<div class="empty-state">No transactions yet.</div>'; return; }
    content.innerHTML = `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Learner</th><th>Type</th><th>Amount</th><th>Balance</th><th>Reason</th></tr></thead><tbody>
      ${transactions.map(t => `<tr>
        <td>${fmtDateTime(t.at)}</td>
        <td>${escapeHtml(t.learnerName)}</td>
        <td>${t.type}</td>
        <td>${t.amount}</td>
        <td>${t.balanceAfter}</td>
        <td>${escapeHtml(t.reason)}</td>
      </tr>`).join('')}
    </tbody></table></div>`;
  } catch (err) {
    content.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}

// --- Job Applications tab ---
async function renderAdminApplicationsTab(content) {
  try {
    const { applications } = await Api.adminJobApplications();
    if (!applications.length) { content.innerHTML = '<div class="empty-state">No job applications yet.</div>'; return; }
    const statuses = ['submitted', 'reviewed', 'shortlisted', 'rejected', 'hired'];
    content.innerHTML = `<div class="table-wrap"><table><thead><tr><th>Learner</th><th>Role</th><th>Submitted</th><th>Status</th></tr></thead><tbody>
      ${applications.map(a => `<tr>
        <td>${escapeHtml(a.learnerName)}<br><span class="muted small">${escapeHtml(a.learnerEmail)} · ${escapeHtml(a.learnerPhone || '')}</span></td>
        <td>${escapeHtml(a.roleTitle)}${a.coverMessage ? `<br><span class="muted small">"${escapeHtml(a.coverMessage)}"</span>` : ''}</td>
        <td>${fmtDate(a.submittedAt)}</td>
        <td><select data-app-status="${a.id}">${statuses.map(s => `<option value="${s}" ${s === a.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
      </tr>`).join('')}
    </tbody></table></div>`;
    content.querySelectorAll('[data-app-status]').forEach(sel => {
      sel.addEventListener('change', async () => {
        try { await Api.adminUpdateJobApplication(sel.getAttribute('data-app-status'), sel.value); }
        catch (err) { alert(err.message); }
      });
    });
  } catch (err) {
    content.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}

// --- Consultations tab ---
async function renderAdminConsultationsTab(content) {
  try {
    const { consultations } = await Api.adminConsultations();
    if (!consultations.length) { content.innerHTML = '<div class="empty-state">No consultation requests yet.</div>'; return; }
    const statuses = ['requested', 'scheduled', 'completed', 'cancelled'];
    content.innerHTML = `<div class="table-wrap"><table><thead><tr><th>Learner</th><th>Topic</th><th>Requested</th><th>Type</th><th>Status</th></tr></thead><tbody>
      ${consultations.map(c => `<tr>
        <td>${escapeHtml(c.learnerName)}<br><span class="muted small">${escapeHtml(c.learnerEmail)} · ${escapeHtml(c.learnerPhone || '')}</span></td>
        <td>${escapeHtml(c.topic)}${c.message ? `<br><span class="muted small">${escapeHtml(c.message)}</span>` : ''}${c.preferredTime ? `<br><span class="muted small">Preferred: ${escapeHtml(c.preferredTime)}</span>` : ''}</td>
        <td>${fmtDateTime(c.requestedAt)}</td>
        <td>${c.isFree ? 'Free' : c.wingsCost + ' ✈'}</td>
        <td><select data-consult-status="${c.id}">${statuses.map(s => `<option value="${s}" ${s === c.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
      </tr>`).join('')}
    </tbody></table></div>`;
    content.querySelectorAll('[data-consult-status]').forEach(sel => {
      sel.addEventListener('change', async () => {
        try { await Api.adminUpdateConsultation(sel.getAttribute('data-consult-status'), sel.value); }
        catch (err) { alert(err.message); }
      });
    });
  } catch (err) {
    content.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}

// --- Manage Job Roles tab ---
async function renderAdminRolesTab(content) {
  try {
    const { jobRoles } = await Api.adminJobRoles();
    content.innerHTML = `
      <div class="card" style="margin-bottom:20px;">
        <h4 style="margin-top:0;color:var(--navy);">Add a Job Role</h4>
        <div id="role-form-error"></div>
        <form id="role-create-form">
          <div class="grid grid-2">
            <div class="form-group"><label>Title</label><input type="text" id="role-title" required></div>
            <div class="form-group"><label>Category</label><input type="text" id="role-category"></div>
            <div class="form-group"><label>Location</label><input type="text" id="role-location"></div>
            <div class="form-group"><label>Requirements</label><input type="text" id="role-requirements"></div>
          </div>
          <div class="form-group"><label>Description</label><textarea id="role-description" rows="2"></textarea></div>
          <button type="submit" class="btn btn-primary btn-sm">Add Role</button>
        </form>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Title</th><th>Category</th><th>Location</th><th>Active</th><th></th></tr></thead>
          <tbody>
            ${jobRoles.map(r => `<tr>
              <td>${escapeHtml(r.title)}</td>
              <td>${escapeHtml(r.category)}</td>
              <td>${escapeHtml(r.location)}</td>
              <td><input type="checkbox" data-toggle-active="${r.id}" ${r.active ? 'checked' : ''}></td>
              <td><button class="btn btn-danger btn-sm" data-delete-role="${r.id}">Delete</button></td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    `;

    document.getElementById('role-create-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const errEl = document.getElementById('role-form-error');
      clearBanner(errEl);
      try {
        await Api.adminCreateJobRole({
          title: document.getElementById('role-title').value.trim(),
          category: document.getElementById('role-category').value.trim(),
          location: document.getElementById('role-location').value.trim(),
          requirements: document.getElementById('role-requirements').value.trim(),
          description: document.getElementById('role-description').value.trim()
        });
        renderAdminRolesTab(content);
      } catch (err) {
        showBanner(errEl, err.message, 'error');
      }
    });

    content.querySelectorAll('[data-toggle-active]').forEach(cb => {
      cb.addEventListener('change', async () => {
        try { await Api.adminUpdateJobRole(cb.getAttribute('data-toggle-active'), { active: cb.checked }); }
        catch (err) { alert(err.message); cb.checked = !cb.checked; }
      });
    });
    content.querySelectorAll('[data-delete-role]').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (!confirm('Delete this job role permanently?')) return;
        try { await Api.adminDeleteJobRole(btn.getAttribute('data-delete-role')); renderAdminRolesTab(content); }
        catch (err) { alert(err.message); }
      });
    });
  } catch (err) {
    content.innerHTML = `<div class="error-banner">${escapeHtml(err.message)}</div>`;
  }
}
