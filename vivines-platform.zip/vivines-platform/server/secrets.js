// server/secrets.js
// Auto-generates and persists a JWT signing secret and an admin passcode on
// first run, so the platform works with zero manual configuration.
// Both values are written to server/data/secrets.json (gitignored) the first
// time the server starts, and reused on every subsequent start.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const SECRETS_PATH = path.join(__dirname, 'data', 'secrets.json');

function generateReadablePasscode() {
  // 8-character human-typeable passcode, e.g. "K7F2-QX9M"
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I to avoid confusion
  let out = '';
  for (let i = 0; i < 8; i++) {
    out += chars[crypto.randomInt(0, chars.length)];
    if (i === 3) out += '-';
  }
  return out;
}

function loadOrCreateSecrets() {
  try {
    if (fs.existsSync(SECRETS_PATH)) {
      const raw = fs.readFileSync(SECRETS_PATH, 'utf8');
      const parsed = JSON.parse(raw);
      if (parsed.jwtSecret && parsed.adminPasscode) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('[secrets] Could not read existing secrets.json, regenerating:', err.message);
  }

  const fresh = {
    jwtSecret: crypto.randomBytes(48).toString('hex'),
    adminPasscode: generateReadablePasscode(),
    createdAt: new Date().toISOString()
  };

  fs.mkdirSync(path.dirname(SECRETS_PATH), { recursive: true });
  fs.writeFileSync(SECRETS_PATH, JSON.stringify(fresh, null, 2), 'utf8');

  console.log('\n================ VIVINES PLATFORM — FIRST RUN ================');
  console.log(' A new admin passcode has been generated for this install:');
  console.log('   ADMIN PASSCODE:', fresh.adminPasscode);
  console.log(' It is saved in server/data/secrets.json — keep that file private.');
  console.log(' Use this passcode on the /admin login screen.');
  console.log('=================================================================\n');

  return fresh;
}

const secrets = loadOrCreateSecrets();

module.exports = {
  JWT_SECRET: secrets.jwtSecret,
  ADMIN_PASSCODE: secrets.adminPasscode
};
