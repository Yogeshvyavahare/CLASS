// server/middleware/auth.js
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../secrets');
const { readDb } = require('../db');

function signLearnerToken(user) {
  return jwt.sign({ sub: user.id, role: 'learner' }, JWT_SECRET, { expiresIn: '30d' });
}

function signAdminToken() {
  return jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '12h' });
}

function getBearerToken(req) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  if (scheme === 'Bearer' && token) return token;
  return null;
}

// Requires a valid learner JWT. Attaches req.user (the full DB user record,
// minus password hash) and req.userId.
function requireLearner(req, res, next) {
  const token = getBearerToken(req);
  if (!token) return res.status(401).json({ error: 'Not authenticated.' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    if (payload.role !== 'learner') return res.status(403).json({ error: 'Learner access required.' });
    const db = readDb();
    const user = db.users.find(u => u.id === payload.sub);
    if (!user) return res.status(401).json({ error: 'Account not found.' });
    if (user.suspended) return res.status(403).json({ error: 'This account has been suspended. Contact the institute.' });
    const { passwordHash, ...safeUser } = user;
    req.user = safeUser;
    req.userId = user.id;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired session.' });
  }
}

// Requires a valid admin JWT (issued only via the admin passcode login).
function requireAdmin(req, res, next) {
  const token = getBearerToken(req);
  if (!token) return res.status(401).json({ error: 'Admin authentication required.' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    if (payload.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired admin session.' });
  }
}

module.exports = { signLearnerToken, signAdminToken, requireLearner, requireAdmin };
