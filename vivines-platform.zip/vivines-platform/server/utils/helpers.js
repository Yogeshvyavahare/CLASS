// server/utils/helpers.js
const { nextId } = require('../db');

// Appends an activity log entry. Call inside a db.mutate() callback so it's
// part of the same atomic write as whatever action triggered it.
function logActivity(db, userId, action, detail) {
  db.activityLog.push({
    id: nextId('log'),
    userId,
    action,
    detail: detail || '',
    at: new Date().toISOString()
  });
}

// Applies a Wings transaction to a user's balance and records it in the
// ledger. `amount` is negative for a debit (spending Wings), positive for a
// credit (earning/receiving Wings). Returns { ok, balanceAfter } — ok is
// false if a debit would take the balance below zero, in which case NOTHING
// is applied (caller should treat this as "insufficient Wings").
function applyWingsTransaction(db, userId, amount, reason, type) {
  const user = db.users.find(u => u.id === userId);
  if (!user) return { ok: false, error: 'User not found' };

  const balanceAfter = user.wings + amount;
  if (balanceAfter < 0) {
    return { ok: false, error: 'Insufficient Wings', balance: user.wings };
  }

  user.wings = balanceAfter;
  db.transactions.push({
    id: nextId('txn'),
    userId,
    type: type || (amount >= 0 ? 'credit' : 'debit'),
    amount,
    balanceAfter,
    reason: reason || '',
    at: new Date().toISOString()
  });

  return { ok: true, balanceAfter };
}

function sanitizeUser(user) {
  if (!user) return null;
  const { passwordHash, ...safe } = user;
  return safe;
}

module.exports = { logActivity, applyWingsTransaction, sanitizeUser };
