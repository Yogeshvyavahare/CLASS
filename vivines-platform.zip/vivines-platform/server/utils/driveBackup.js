// server/utils/driveBackup.js
// Optional Google Drive backup of server/data/db.json, via a Google service
// account. Fully optional — if no service account key is configured, this
// module silently no-ops so the app still runs perfectly without it.
//
// To enable: create a Google Cloud service account with Drive API access,
// download its JSON key, save it as server/data/service-account.json (or
// point GOOGLE_SERVICE_ACCOUNT_KEY_PATH at it), and set
// GOOGLE_DRIVE_BACKUP_FOLDER_ID to a folder shared with that service
// account's email address. See README.md for full step-by-step setup.

const fs = require('fs');
const path = require('path');

const KEY_PATH = process.env.GOOGLE_SERVICE_ACCOUNT_KEY_PATH
  || path.join(__dirname, '..', 'data', 'service-account.json');
const FOLDER_ID = process.env.GOOGLE_DRIVE_BACKUP_FOLDER_ID;

const isConfigured = Boolean(FOLDER_ID && fs.existsSync(KEY_PATH));

let driveClient = null;

async function getDriveClient() {
  if (!isConfigured) return null;
  if (driveClient) return driveClient;
  try {
    // googleapis is an optionalDependency — only required if this feature
    // is actually configured, so a bare `npm install` never fails on it.
    const { google } = require('googleapis');
    const auth = new google.auth.GoogleAuth({
      keyFile: KEY_PATH,
      scopes: ['https://www.googleapis.com/auth/drive.file']
    });
    driveClient = google.drive({ version: 'v3', auth });
    return driveClient;
  } catch (err) {
    console.warn('[driveBackup] googleapis not installed or key invalid — Drive backup disabled:', err.message);
    return null;
  }
}

let existingFileId = null;

async function backupNow(dbFilePath) {
  if (!isConfigured) return { skipped: true };
  const drive = await getDriveClient();
  if (!drive) return { skipped: true };

  try {
    const media = { mimeType: 'application/json', body: fs.createReadStream(dbFilePath) };

    if (existingFileId) {
      await drive.files.update({ fileId: existingFileId, media });
      return { skipped: false, updated: true, fileId: existingFileId };
    }

    // Look for an existing backup file first so restarts don't create dupes.
    const list = await drive.files.list({
      q: `'${FOLDER_ID}' in parents and name = 'vivines-db-backup.json' and trashed = false`,
      fields: 'files(id, name)'
    });
    if (list.data.files && list.data.files.length > 0) {
      existingFileId = list.data.files[0].id;
      await drive.files.update({ fileId: existingFileId, media });
      return { skipped: false, updated: true, fileId: existingFileId };
    }

    const created = await drive.files.create({
      requestBody: { name: 'vivines-db-backup.json', parents: [FOLDER_ID] },
      media,
      fields: 'id'
    });
    existingFileId = created.data.id;
    return { skipped: false, created: true, fileId: existingFileId };
  } catch (err) {
    console.error('[driveBackup] Backup failed (continuing without it):', err.message);
    return { skipped: false, error: err.message };
  }
}

// Debounced backup trigger — call after any db mutation; only actually
// backs up at most once every BACKUP_INTERVAL_MS to avoid hammering the
// Drive API on bursts of activity.
const BACKUP_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes
let pending = false;
let timer = null;

function scheduleBackup(dbFilePath) {
  if (!isConfigured) return;
  if (pending) return;
  pending = true;
  timer = setTimeout(async () => {
    pending = false;
    await backupNow(dbFilePath);
  }, BACKUP_INTERVAL_MS);
  if (timer.unref) timer.unref();
}

module.exports = { isConfigured, backupNow, scheduleBackup };
