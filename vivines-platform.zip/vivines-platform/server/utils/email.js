// server/utils/email.js
// Transactional email via nodemailer. If SMTP env vars aren't set, the app
// degrades gracefully: emails are logged to the console instead of sent,
// so the platform works out of the box with zero email configuration.

const nodemailer = require('nodemailer');

const SMTP_HOST = process.env.SMTP_HOST;
const SMTP_PORT = process.env.SMTP_PORT;
const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;
const FROM_ADDRESS = process.env.SMTP_FROM || 'Vivines International <no-reply@vivines.example>';

const isConfigured = Boolean(SMTP_HOST && SMTP_PORT && SMTP_USER && SMTP_PASS);

let transporter = null;
if (isConfigured) {
  transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: Number(SMTP_PORT) === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });
} else {
  console.log('[email] SMTP not configured — emails will be logged to console instead of sent.');
  console.log('[email] Set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM in .env to enable real email.');
}

async function sendEmail({ to, subject, html, text }) {
  if (!isConfigured) {
    console.log(`\n[email:DEGRADED-MODE] Would send email —\n  To: ${to}\n  Subject: ${subject}\n  Body: ${text || (html || '').replace(/<[^>]+>/g, ' ').slice(0, 300)}\n`);
    return { degraded: true, sent: false };
  }
  try {
    const info = await transporter.sendMail({ from: FROM_ADDRESS, to, subject, html, text });
    return { degraded: false, sent: true, messageId: info.messageId };
  } catch (err) {
    console.error('[email] Send failed:', err.message);
    return { degraded: false, sent: false, error: err.message };
  }
}

// --- Templated helpers used across routes ---

function welcomeEmail(user) {
  return sendEmail({
    to: user.email,
    subject: 'Welcome to Vivines International — Success Meets Here',
    text: `Hi ${user.fullName},\n\nYour Vivines International learner account is ready. You've been credited 10 Wings to get started.\n\nLog in and begin your first module whenever you're ready.\n\n— Vivines International`,
    html: `<p>Hi ${user.fullName},</p><p>Your Vivines International learner account is ready. You've been credited <strong>10 Wings</strong> to get started.</p><p>Log in and begin your first module whenever you're ready.</p><p>— Vivines International</p>`
  });
}

function certificateIssuedEmail(user, categoryLabel) {
  return sendEmail({
    to: user.email,
    subject: `Your ${categoryLabel} certificate is ready`,
    text: `Hi ${user.fullName},\n\nCongratulations! Your certificate for "${categoryLabel}" has been issued and is available in your Vivines dashboard under Certificates.\n\n— Vivines International`,
    html: `<p>Hi ${user.fullName},</p><p>Congratulations! Your certificate for <strong>${categoryLabel}</strong> has been issued and is available in your Vivines dashboard under Certificates.</p><p>— Vivines International</p>`
  });
}

function consultationConfirmationEmail(user, consultation) {
  return sendEmail({
    to: user.email,
    subject: 'Your Vivines consultation request has been received',
    text: `Hi ${user.fullName},\n\nWe've received your consultation request (${consultation.topic}). The Training & Recruitment Support team will reach out to you shortly at ${user.email} or via WhatsApp.\n\n— Vivines International`,
    html: `<p>Hi ${user.fullName},</p><p>We've received your consultation request (<strong>${consultation.topic}</strong>). The Training & Recruitment Support team will reach out to you shortly.</p><p>— Vivines International</p>`
  });
}

module.exports = { sendEmail, welcomeEmail, certificateIssuedEmail, consultationConfirmationEmail, isConfigured };
