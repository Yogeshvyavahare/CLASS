// server/utils/certificate.js
// Generates a certificate PDF for a learner who has completed every unit
// assessment in a category (or the Capstone/Full Programme) and paid the
// Wings cost to claim it. Certificates are only ever generated server-side,
// after verifying real completion — see routes/certificates.js.

const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

const CERT_DIR = path.join(__dirname, '..', 'data', 'certificates');
fs.mkdirSync(CERT_DIR, { recursive: true });

const BRAND_NAVY = '#0B2545';
const BRAND_GOLD = '#C9A24B';
const BRAND_SLATE = '#4A5568';

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' });
}

/**
 * Generates a certificate PDF and returns its file path (relative to
 * server/data/certificates/, which is what gets stored in the DB record).
 *
 * @param {Object} opts
 * @param {string} opts.certificateId - unique cert id, used as the filename base
 * @param {string} opts.learnerName - full name as registered
 * @param {string} opts.categoryLabel - e.g. "Hospitality Management" or "Full Programme"
 * @param {string} opts.issuedAtISO - ISO date string
 * @param {string} [opts.photoPath] - absolute path to the learner's uploaded photo, if available
 * @param {string} [opts.logoPath] - absolute path to the Vivines logo, if available
 */
async function generateCertificatePdf({ certificateId, learnerName, categoryLabel, issuedAtISO, photoPath, logoPath }) {
  const fileName = `${certificateId}.pdf`;
  const outPath = path.join(CERT_DIR, fileName);

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', layout: 'landscape', margin: 0 });
    const stream = fs.createWriteStream(outPath);
    doc.pipe(stream);

    const pageW = doc.page.width;
    const pageH = doc.page.height;

    // Background
    doc.rect(0, 0, pageW, pageH).fill('#FFFFFF');

    // Decorative border
    doc.lineWidth(3).strokeColor(BRAND_NAVY).rect(24, 24, pageW - 48, pageH - 48).stroke();
    doc.lineWidth(1).strokeColor(BRAND_GOLD).rect(34, 34, pageW - 68, pageH - 68).stroke();

    // Logo — the real Vivines mark already includes the wordmark and
    // tagline, so when it renders we skip the separate text wordmark below.
    const logoY = 44;
    let contentTop = logoY + 55;
    let logoRendered = false;
    if (logoPath && fs.existsSync(logoPath)) {
      try {
        const logoWidth = 190;
        const logoHeight = logoWidth * (322 / 750); // real logo's native aspect ratio
        doc.image(logoPath, pageW / 2 - logoWidth / 2, logoY, { width: logoWidth });
        logoRendered = true;
        contentTop = logoY + logoHeight + 18;
      } catch (e) { /* fall through to text wordmark below */ }
    }

    if (!logoRendered) {
      doc.fillColor(BRAND_NAVY).font('Helvetica-Bold').fontSize(26)
        .text('VIVINES INTERNATIONAL', 0, logoY + 55, { align: 'center' });
      doc.fillColor(BRAND_SLATE).font('Helvetica').fontSize(11)
        .text('Success Meets Here', 0, logoY + 86, { align: 'center' });
      contentTop = logoY + 120;
    }

    doc.fillColor(BRAND_GOLD).font('Helvetica-Bold').fontSize(16)
      .text('CERTIFICATE OF COMPLETION', 0, contentTop, { align: 'center', characterSpacing: 2 });

    doc.fillColor(BRAND_SLATE).font('Helvetica').fontSize(12)
      .text('This certifies that', 0, contentTop + 40, { align: 'center' });

    doc.fillColor(BRAND_NAVY).font('Helvetica-Bold').fontSize(28)
      .text(learnerName, 0, contentTop + 62, { align: 'center' });

    doc.fillColor(BRAND_SLATE).font('Helvetica').fontSize(12)
      .text('has successfully completed all required unit assessments in', 0, contentTop + 104, { align: 'center' });

    doc.fillColor(BRAND_NAVY).font('Helvetica-Bold').fontSize(20)
      .text(categoryLabel, 0, contentTop + 126, { align: 'center' });

    doc.fillColor(BRAND_SLATE).font('Helvetica').fontSize(11)
      .text('as part of the Vivines International Online Aviation & Hospitality Certification Programme.', 0, contentTop + 160, { align: 'center', width: pageW, lineBreak: true });

    // Photo (learner passport photo), bottom-left
    const photoBoxX = 90;
    const photoBoxY = pageH - 150;
    if (photoPath && fs.existsSync(photoPath)) {
      try {
        doc.rect(photoBoxX, photoBoxY, 70, 90).lineWidth(1).strokeColor(BRAND_NAVY).stroke();
        doc.image(photoPath, photoBoxX + 2, photoBoxY + 2, { width: 66, height: 86, fit: [66, 86] });
      } catch (e) { /* ignore bad image */ }
    }

    // Issue date + certificate ID, bottom-center
    doc.fillColor(BRAND_SLATE).font('Helvetica').fontSize(10)
      .text(`Issued on ${formatDate(issuedAtISO)}`, 0, pageH - 110, { align: 'center' });
    doc.fontSize(8).fillColor('#8A8F98')
      .text(`Certificate ID: ${certificateId}`, 0, pageH - 92, { align: 'center' });
    doc.fontSize(8).fillColor('#8A8F98')
      .text('Verify this certificate via the learner\'s Vivines account or by contacting hr.vivines@gmail.com', 0, pageH - 78, { align: 'center' });

    // Signature line, bottom-right
    const sigX = pageW - 260;
    const sigY = pageH - 150;
    doc.moveTo(sigX, sigY + 60).lineTo(sigX + 170, sigY + 60).lineWidth(1).strokeColor(BRAND_SLATE).stroke();
    doc.fillColor(BRAND_NAVY).font('Helvetica-Bold').fontSize(11)
      .text('Prof. Yogesh Vyavahare', sigX, sigY + 65, { width: 170, align: 'center' });
    doc.fillColor(BRAND_SLATE).font('Helvetica').fontSize(9)
      .text('Programme Director, Vivines International', sigX, sigY + 80, { width: 170, align: 'center' });

    doc.end();
    stream.on('finish', () => resolve({ filePath: outPath, fileName }));
    stream.on('error', reject);
  });
}

module.exports = { generateCertificatePdf, CERT_DIR };
