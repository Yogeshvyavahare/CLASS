// server/server.js
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');

const { readDb, mutate, DB_PATH } = require('./db');
require('./secrets'); // triggers first-run secret/passcode generation + console log

const translations = require('./data/translations');
const jobRolesSeed = require('./data/jobRoles');
const { nextId } = require('./db');
const { isConfigured: emailConfigured } = require('./utils/email');
const { isConfigured: driveConfigured } = require('./utils/driveBackup');

const authRoutes = require('./routes/auth');
const unitsRoutes = require('./routes/units');
const quizRoutes = require('./routes/quiz');
const wingsRoutes = require('./routes/wings');
const certificatesRoutes = require('./routes/certificates');
const consultationsRoutes = require('./routes/consultations');
const jobsRoutes = require('./routes/jobs');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '2mb' }));

// ---------- One-time seed: job roles (only if none exist yet) ----------
(async () => {
  const db = readDb();
  if (!db.jobRoles || db.jobRoles.length === 0) {
    await mutate((dbInner) => {
      dbInner.jobRoles = jobRolesSeed.map(r => ({ ...r, id: nextId('role'), createdAt: new Date().toISOString() }));
      dbInner.meta.seededAt = new Date().toISOString();
    });
    console.log(`[seed] Loaded ${jobRolesSeed.length} starter job roles into the Career Opportunities board.`);
  }
})();

// ---------- Public, unauthenticated endpoints ----------
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    emailConfigured,
    driveBackupConfigured: driveConfigured,
    time: new Date().toISOString()
  });
});

app.get('/api/i18n', (req, res) => {
  res.json(translations);
});

// ---------- API routes ----------
app.use('/api/auth', authRoutes);
app.use('/api/units', unitsRoutes);
app.use('/api/units', quizRoutes); // adds POST /api/units/:id/submit
app.use('/api/wings', wingsRoutes);
app.use('/api/certificates', certificatesRoutes);
app.use('/api/consultations', consultationsRoutes);
app.use('/api/jobs', jobsRoutes);
app.use('/api/admin', adminRoutes);

// ---------- Static frontend ----------
app.use(express.static(path.join(__dirname, '..', 'public')));

// SPA-style fallback: any non-API GET that isn't a static file goes to index.html
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// ---------- Error handler (catches multer errors, JSON parse errors, etc.) ----------
app.use((err, req, res, next) => {
  console.error('[unhandled error]', err.message);
  if (err.type === 'entity.too.large') {
    return res.status(413).json({ error: 'Request too large.' });
  }
  res.status(err.status || 500).json({ error: err.message || 'Something went wrong on the server.' });
});

app.listen(PORT, () => {
  console.log(`\nVivines International platform running on http://localhost:${PORT}`);
  console.log(`Database file: ${DB_PATH}`);
  console.log(`Email: ${emailConfigured ? 'configured (SMTP)' : 'DEGRADED MODE — logging to console'}`);
  console.log(`Google Drive backup: ${driveConfigured ? 'enabled' : 'disabled (optional)'}\n`);
});

module.exports = app;
