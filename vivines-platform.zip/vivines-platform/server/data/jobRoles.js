// server/data/jobRoles.js
// Seed data for the "Career Opportunities" board, unlocked post-certification.
// Admins can add/edit/remove roles from the admin panel — this is just the
// starting set so the board isn't empty on a fresh install.

module.exports = [
  {
    title: 'Ground Staff / Passenger Service Agent',
    category: 'Airport Operations',
    description: 'Front-line airport role handling check-in, boarding, and passenger assistance for domestic and international flights.',
    requirements: 'Vivines certification (Aviation Fundamentals + Passenger Services modules), 12th pass minimum, fluent English/Hindi/regional language.',
    location: 'Multiple Maharashtra airports',
    active: true
  },
  {
    title: 'Cabin Crew Trainee',
    category: 'Cabin Crew & Safety',
    description: 'Entry-level cabin crew training pipeline with partner airlines, subject to airline-specific medical and height/reach criteria.',
    requirements: 'Vivines certification (Cabin Crew & Safety module), 12th pass, meets partner airline eligibility criteria.',
    location: 'Pan-India, based on airline base allocation',
    active: true
  },
  {
    title: 'Airport Ramp / Ground Handling Associate',
    category: 'Airport Operations',
    description: 'Ramp-side operations including baggage handling, marshalling support and turnaround coordination.',
    requirements: 'Vivines certification (Airport Operations module), physically fit, willing to work rotational shifts.',
    location: 'Multiple Maharashtra airports',
    active: true
  },
  {
    title: 'Travel Consultant / Ticketing Executive',
    category: 'Airline Ticketing & GDS',
    description: 'Fare quoting, PNR creation and itinerary building for a retail travel agency or corporate travel desk.',
    requirements: 'Vivines certification (Airline Ticketing & GDS module), basic computer literacy.',
    location: 'Pune / Mumbai',
    active: true
  },
  {
    title: 'Hotel Front Office Associate',
    category: 'Hospitality Management',
    description: 'Guest check-in/out, reservations support and guest relations at a partner hotel property.',
    requirements: 'Vivines certification (Hospitality Management module), well-groomed, guest-service orientation.',
    location: 'Maharashtra hospitality partners',
    active: true
  },
  {
    title: 'Tour Executive',
    category: 'Travel & Tourism',
    description: 'Tour package design support, client coordination and on-ground trip assistance for domestic circuits.',
    requirements: 'Vivines certification (Travel & Tourism module), strong communication skills.',
    location: 'Pune',
    active: true
  }
];
