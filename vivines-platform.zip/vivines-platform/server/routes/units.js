// server/routes/units.js
const express = require('express');
const { UNITS, MODULE_GROUP_PRICING } = require('../data/content');
const { requireLearner } = require('../middleware/auth');
const { mutate, readDb, DB_PATH } = require('../db');
const { logActivity, applyWingsTransaction, sanitizeUser } = require('../utils/helpers');
const { scheduleBackup } = require('../utils/driveBackup');

const router = express.Router();

function unitCost(unit) {
  return MODULE_GROUP_PRICING[unit.category] ?? 5;
}

// Strips correct answers and returns only what the client needs before a
// unit is unlocked (metadata) or after unlock (study material + questions
// minus correctIndex).
function publicUnitSummary(unit, learner) {
  const unlocked = learner.unlockedUnits.includes(unit.id);
  const completed = learner.completedUnits.includes(unit.id);
  return {
    id: unit.id,
    category: unit.category,
    title: unit.title,
    wingsCost: unitCost(unit),
    unlocked,
    completed,
    questionCount: unit.questions.length,
    attempts: (learner.quizAttempts[unit.id] || []).length
  };
}

// GET /api/units — list all units with per-learner unlock/completion status,
// grouped by category for convenient rendering.
router.get('/', requireLearner, (req, res) => {
  const summaries = UNITS.map(u => publicUnitSummary(u, req.user));
  const grouped = {};
  summaries.forEach(s => {
    if (!grouped[s.category]) grouped[s.category] = [];
    grouped[s.category].push(s);
  });
  res.json({ units: summaries, grouped });
});

// GET /api/units/:id — study material + questions (no correct answers),
// only if the learner has unlocked this unit.
router.get('/:id', requireLearner, (req, res) => {
  const unit = UNITS.find(u => u.id === req.params.id);
  if (!unit) return res.status(404).json({ error: 'Unit not found.' });
  if (!req.user.unlockedUnits.includes(unit.id)) {
    return res.status(403).json({ error: 'This unit is locked. Unlock it with Wings first.' });
  }
  res.json({
    id: unit.id,
    category: unit.category,
    title: unit.title,
    studyMaterial: unit.studyMaterial,
    questions: unit.questions.map(q => ({ id: q.id, bloom: q.bloom, text: q.text, options: q.options })),
    completed: req.user.completedUnits.includes(unit.id),
    attempts: req.user.quizAttempts[unit.id] || []
  });
});

// POST /api/units/:id/unlock — spend Wings to unlock a unit
router.post('/:id/unlock', requireLearner, async (req, res) => {
  const unit = UNITS.find(u => u.id === req.params.id);
  if (!unit) return res.status(404).json({ error: 'Unit not found.' });

  if (req.user.unlockedUnits.includes(unit.id)) {
    return res.status(200).json({ message: 'Already unlocked.', alreadyUnlocked: true });
  }

  const cost = unitCost(unit);
  let result;
  await mutate((db) => {
    const user = db.users.find(u => u.id === req.userId);
    result = applyWingsTransaction(db, req.userId, -cost, `Unlocked unit: ${unit.title}`, 'debit');
    if (result.ok) {
      user.unlockedUnits.push(unit.id);
      logActivity(db, req.userId, 'unit_unlocked', unit.title);
    }
  });

  scheduleBackup(DB_PATH);

  if (!result.ok) {
    return res.status(402).json({ error: `You need ${cost} Wings to unlock this unit. Current balance: ${result.balance}.` });
  }

  const db = readDb();
  const updatedUser = db.users.find(u => u.id === req.userId);
  res.json({ message: 'Unit unlocked.', wings: updatedUser.wings, user: sanitizeUser(updatedUser) });
});

module.exports = router;
