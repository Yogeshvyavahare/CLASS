// server/routes/admin.js
const express = require('express');
const path = require('path');
const fs = require('fs');

const { requireAdmin } = require('../middleware/auth');
const { mutate, readDb, nextId, DB_PATH } = require('../db');
const { sanitizeUser, logActivity } = require('../utils/helpers');
const { UNITS } = require('../data/content');
const { scheduleBackup } = require('../utils/driveBackup');

const router = express.Router();
router.use(requireAdmin);

const CATEGORIES = [...new Set(UNITS.map(u => u.category))];

// ---------- Dashboard overview ----------
router.get('/stats', (req, res) => {
  const db = readDb();
  res.json({
    totalLearners: db.users.length,
    activeLearners: db.users.filter(u => !u.suspended).length,
    suspendedLearners: db.users.filter(u => u.suspended).length,
    totalCertificatesIssued: db.certificates.length,
    totalWingsInCirculation: db.users.reduce((sum, u) => sum + u.wings, 0),
    totalWingsSpent: db.transactions.filter(t => t.amount < 0).reduce((s, t) => s + Math.abs(t.amount), 0),
    pendingConsultations: db.consultations.filter(c => c.status === 'requested').length,
    totalJobApplications: db.jobApplications.length,
    unitsPublished: UNITS.length,
    questionsPublished: UNITS.reduce((s, u) => s + u.questions.length, 0)
  });
});

// ---------- Learners ----------
router.get('/learners', (req, res) => {
  const db = readDb();
  const q = (req.query.q || '').toLowerCase();
  let learners = db.users.map(sanitizeUser);
  if (q) {
    learners = learners.filter(u => u.fullName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
  }
  // Don't ship full quizAttempts/unlockedUnits arrays in the list view — just counts
  const summarized = learners.map(u => ({
    id: u.id, fullName: u.fullName, email: u.email, phone: u.phone, wings: u.wings,
    unitsCompleted: u.completedUnits.length, unitsUnlocked: u.unlockedUnits.length,
    certificatesClaimed: u.claimedCertificates.length, suspended: u.suspended, createdAt: u.createdAt
  }));
  res.json({ learners: summarized });
});

router.get('/learners/:id', (req, res) => {
  const db = readDb();
  const user = db.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'Learner not found.' });

  const activity = db.activityLog.filter(l => l.userId === user.id).sort((a, b) => new Date(b.at) - new Date(a.at));
  const transactions = db.transactions.filter(t => t.userId === user.id).sort((a, b) => new Date(b.at) - new Date(a.at));
  const certificates = db.certificates.filter(c => c.userId === user.id);
  const applications = db.jobApplications.filter(a => a.userId === user.id);
  const consultations = db.consultations.filter(c => c.userId === user.id);

  res.json({
    user: sanitizeUser(user),
    activity, transactions, certificates, applications, consultations
  });
});

// PATCH /api/admin/learners/:id — { suspended?: bool, adjustWings?: number, adjustReason?: string }
router.patch('/learners/:id', async (req, res) => {
  const { suspended, adjustWings, adjustReason } = req.body;
  const db = readDb();
  const user = db.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'Learner not found.' });

  let result = null;
  await mutate((dbInner) => {
    const u = dbInner.users.find(x => x.id === req.params.id);
    if (typeof suspended === 'boolean') {
      u.suspended = suspended;
      logActivity(dbInner, u.id, suspended ? 'account_suspended' : 'account_reinstated', 'By admin');
    }
    if (typeof adjustWings === 'number' && adjustWings !== 0) {
      result = require('../utils/helpers').applyWingsTransaction(
        dbInner, u.id, adjustWings, adjustReason || 'Manual admin adjustment', adjustWings >= 0 ? 'credit' : 'debit'
      );
      if (result.ok) logActivity(dbInner, u.id, 'wings_adjusted_by_admin', `${adjustWings > 0 ? '+' : ''}${adjustWings}: ${adjustReason || ''}`);
    }
  });

  if (result && !result.ok) {
    return res.status(400).json({ error: 'Wings adjustment would take balance below zero.' });
  }

  scheduleBackup(DB_PATH);
  const updated = readDb().users.find(u => u.id === req.params.id);
  res.json({ user: sanitizeUser(updated) });
});

// ---------- Certificates ----------
router.get('/certificates', (req, res) => {
  const db = readDb();
  const records = db.certificates.map(c => {
    const user = db.users.find(u => u.id === c.userId);
    return { ...c, learnerName: user ? user.fullName : 'Unknown', learnerEmail: user ? user.email : '' };
  });
  res.json({ certificates: records.sort((a, b) => new Date(b.issuedAt) - new Date(a.issuedAt)) });
});

router.get('/certificates/:id/download', (req, res) => {
  const db = readDb();
  const record = db.certificates.find(c => c.id === req.params.id);
  if (!record) return res.status(404).json({ error: 'Certificate not found.' });
  const filePath = path.join(__dirname, '..', 'data', 'certificates', record.fileName);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Certificate file missing on server.' });
  res.download(filePath, `Vivines-Certificate-${record.category}.pdf`);
});

// ---------- Fees & Transactions ----------
router.get('/transactions', (req, res) => {
  const db = readDb();
  const records = db.transactions.map(t => {
    const user = db.users.find(u => u.id === t.userId);
    return { ...t, learnerName: user ? user.fullName : 'Unknown', learnerEmail: user ? user.email : '' };
  });
  res.json({ transactions: records.sort((a, b) => new Date(b.at) - new Date(a.at)) });
});

// ---------- Job Applications ----------
router.get('/job-applications', (req, res) => {
  const db = readDb();
  const records = db.jobApplications.map(a => {
    const user = db.users.find(u => u.id === a.userId);
    return { ...a, learnerName: user ? user.fullName : 'Unknown', learnerEmail: user ? user.email : '', learnerPhone: user ? user.phone : '' };
  });
  res.json({ applications: records.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt)) });
});

router.patch('/job-applications/:id', async (req, res) => {
  const { status } = req.body;
  const allowed = ['submitted', 'reviewed', 'shortlisted', 'rejected', 'hired'];
  if (!allowed.includes(status)) return res.status(400).json({ error: `Status must be one of: ${allowed.join(', ')}` });

  const db = readDb();
  const app = db.jobApplications.find(a => a.id === req.params.id);
  if (!app) return res.status(404).json({ error: 'Application not found.' });

  await mutate((dbInner) => {
    const a = dbInner.jobApplications.find(x => x.id === req.params.id);
    a.status = status;
    logActivity(dbInner, a.userId, 'job_application_status_updated', `${a.roleTitle}: ${status}`);
  });

  scheduleBackup(DB_PATH);
  res.json({ message: 'Updated.' });
});

// ---------- Consultation Requests ----------
router.get('/consultations', (req, res) => {
  const db = readDb();
  const records = db.consultations.map(c => {
    const user = db.users.find(u => u.id === c.userId);
    return { ...c, learnerName: user ? user.fullName : 'Unknown', learnerEmail: user ? user.email : '', learnerPhone: user ? user.phone : '' };
  });
  res.json({ consultations: records.sort((a, b) => new Date(b.requestedAt) - new Date(a.requestedAt)) });
});

router.patch('/consultations/:id', async (req, res) => {
  const { status } = req.body;
  const allowed = ['requested', 'scheduled', 'completed', 'cancelled'];
  if (!allowed.includes(status)) return res.status(400).json({ error: `Status must be one of: ${allowed.join(', ')}` });

  const db = readDb();
  const consult = db.consultations.find(c => c.id === req.params.id);
  if (!consult) return res.status(404).json({ error: 'Consultation not found.' });

  await mutate((dbInner) => {
    const c = dbInner.consultations.find(x => x.id === req.params.id);
    c.status = status;
    logActivity(dbInner, c.userId, 'consultation_status_updated', `${c.topic}: ${status}`);
  });

  scheduleBackup(DB_PATH);
  res.json({ message: 'Updated.' });
});

// ---------- Manage Job Roles ----------
router.get('/job-roles', (req, res) => {
  const db = readDb();
  res.json({ jobRoles: db.jobRoles });
});

router.post('/job-roles', async (req, res) => {
  const { title, category, description, requirements, location } = req.body;
  if (!title) return res.status(400).json({ error: 'Title is required.' });

  const role = {
    id: nextId('role'),
    title, category: category || '', description: description || '',
    requirements: requirements || '', location: location || '',
    active: true, createdAt: new Date().toISOString()
  };

  await mutate((db) => { db.jobRoles.push(role); });
  scheduleBackup(DB_PATH);
  res.status(201).json({ jobRole: role });
});

router.patch('/job-roles/:id', async (req, res) => {
  const db = readDb();
  const role = db.jobRoles.find(r => r.id === req.params.id);
  if (!role) return res.status(404).json({ error: 'Job role not found.' });

  const fields = ['title', 'category', 'description', 'requirements', 'location', 'active'];
  await mutate((dbInner) => {
    const r = dbInner.jobRoles.find(x => x.id === req.params.id);
    fields.forEach(f => { if (req.body[f] !== undefined) r[f] = req.body[f]; });
  });

  scheduleBackup(DB_PATH);
  res.json({ message: 'Updated.' });
});

router.delete('/job-roles/:id', async (req, res) => {
  const db = readDb();
  const exists = db.jobRoles.find(r => r.id === req.params.id);
  if (!exists) return res.status(404).json({ error: 'Job role not found.' });

  await mutate((dbInner) => {
    dbInner.jobRoles = dbInner.jobRoles.filter(r => r.id !== req.params.id);
  });

  scheduleBackup(DB_PATH);
  res.json({ message: 'Deleted.' });
});

// ---------- Learner photo (for admin review) ----------
router.get('/learners/:id/photo', (req, res) => {
  const db = readDb();
  const user = db.users.find(u => u.id === req.params.id);
  if (!user || !user.photoFile) return res.status(404).json({ error: 'No photo on file.' });
  const filePath = path.join(__dirname, '..', 'data', 'uploads', user.photoFile);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Photo file missing on server.' });
  res.sendFile(filePath);
});

module.exports = router;
