// server/routes/wings.js
const express = require('express');
const { requireLearner } = require('../middleware/auth');
const { readDb } = require('../db');

const router = express.Router();

// GET /api/wings — current balance + transaction history for this learner
router.get('/', requireLearner, (req, res) => {
  const db = readDb();
  const history = db.transactions
    .filter(t => t.userId === req.userId)
    .sort((a, b) => new Date(b.at) - new Date(a.at));
  res.json({ balance: req.user.wings, transactions: history });
});

module.exports = router;
