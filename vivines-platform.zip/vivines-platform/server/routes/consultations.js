// server/routes/consultations.js
const express = require('express');
const { requireLearner } = require('../middleware/auth');
const { mutate, readDb, nextId, DB_PATH } = require('../db');
const { logActivity, applyWingsTransaction, sanitizeUser } = require('../utils/helpers');
const { consultationConfirmationEmail } = require('../utils/email');
const { scheduleBackup } = require('../utils/driveBackup');

const router = express.Router();

const SUBSEQUENT_SESSION_COST = 8; // Wings, per spec: "first session free, subsequent sessions cost Wings"

// GET /api/consultations — this learner's own requests
router.get('/', requireLearner, (req, res) => {
  const db = readDb();
  const mine = db.consultations
    .filter(c => c.userId === req.userId)
    .sort((a, b) => new Date(b.requestedAt) - new Date(a.requestedAt));
  res.json({ consultations: mine, nextSessionCost: mine.length === 0 ? 0 : SUBSEQUENT_SESSION_COST });
});

// POST /api/consultations — { topic, preferredTime, message }
router.post('/', requireLearner, async (req, res) => {
  const { topic, preferredTime, message } = req.body;
  if (!topic) return res.status(400).json({ error: 'Please describe the topic you\'d like to discuss.' });

  const db = readDb();
  const priorCount = db.consultations.filter(c => c.userId === req.userId).length;
  const isFree = priorCount === 0;
  const cost = isFree ? 0 : SUBSEQUENT_SESSION_COST;

  let txnResult = { ok: true, balanceAfter: db.users.find(u => u.id === req.userId).wings };
  const record = {
    id: nextId('consult'),
    userId: req.userId,
    topic: topic.trim(),
    preferredTime: preferredTime || '',
    message: message || '',
    isFree,
    wingsCost: cost,
    status: 'requested', // requested -> scheduled -> completed (admin-managed)
    requestedAt: new Date().toISOString()
  };

  await mutate((dbInner) => {
    if (cost > 0) {
      txnResult = applyWingsTransaction(dbInner, req.userId, -cost, 'Consultation session request', 'debit');
      if (!txnResult.ok) return;
    }
    dbInner.consultations.push(record);
    logActivity(dbInner, req.userId, 'consultation_requested', record.topic);
  });

  if (cost > 0 && !txnResult.ok) {
    return res.status(402).json({ error: `Your first session was free — this next session costs ${cost} Wings. Current balance: ${txnResult.balance}.` });
  }

  scheduleBackup(DB_PATH);

  const learner = readDb().users.find(u => u.id === req.userId);
  consultationConfirmationEmail(learner, record).catch(() => {});

  res.status(201).json({ consultation: record, wings: learner.wings, user: sanitizeUser(learner) });
});

module.exports = router;
