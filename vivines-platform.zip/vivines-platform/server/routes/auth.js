// server/routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const { mutate, readDb, nextId } = require('../db');
const { signLearnerToken, signAdminToken, requireLearner } = require('../middleware/auth');
const { ADMIN_PASSCODE } = require('../secrets');
const { logActivity, sanitizeUser } = require('../utils/helpers');
const { welcomeEmail } = require('../utils/email');
const { scheduleBackup } = require('../utils/driveBackup');
const { DB_PATH } = require('../db');

const router = express.Router();

const UPLOAD_DIR = path.join(__dirname, '..', 'data', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
    cb(null, `${nextId('photo')}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowed = ['.jpg', '.jpeg', '.png', '.webp'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowed.includes(ext)) return cb(new Error('Only JPG, PNG or WEBP photos are accepted.'));
    cb(null, true);
  }
});

const STARTING_WINGS = 10;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// POST /api/auth/register — multipart form: fullName, email, password, dob, phone, photo(file)
router.post('/register', upload.single('photo'), async (req, res) => {
  try {
    const { fullName, email, password, dob, phone } = req.body;

    if (!fullName || !email || !password || !dob) {
      return res.status(400).json({ error: 'Full name, email, password and date of birth are required.' });
    }
    if (!EMAIL_RE.test(email)) {
      return res.status(400).json({ error: 'Please provide a valid email address.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }
    const dobDate = new Date(dob);
    if (isNaN(dobDate.getTime()) || dobDate > new Date()) {
      return res.status(400).json({ error: 'Please provide a valid date of birth.' });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'A passport-size photo is required for certificate issuance.' });
    }

    const db = readDb();
    const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      // Clean up the uploaded photo since we're rejecting this registration
      fs.unlink(req.file.path, () => {});
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const userId = nextId('user');
    const newUser = {
      id: userId,
      fullName: fullName.trim(),
      email: email.trim().toLowerCase(),
      passwordHash,
      dob,
      phone: phone ? phone.trim() : '',
      photoFile: req.file.filename,
      wings: 0, // set via the ledger transaction below, so the transaction log and balance never drift apart
      language: 'en',
      unlockedUnits: [],      // unit ids the learner has paid Wings to unlock
      completedUnits: [],     // unit ids where the quiz has been passed
      quizAttempts: {},       // unitId -> array of { score, total, passed, at }
      claimedCertificates: [],// category labels already claimed
      createdAt: new Date().toISOString(),
      suspended: false
    };

    await mutate((dbInner) => {
      dbInner.users.push(newUser);
      logActivity(dbInner, userId, 'account_created', `Registered with email ${newUser.email}`);
      const txnResult = require('../utils/helpers').applyWingsTransaction(dbInner, userId, STARTING_WINGS, 'Signup bonus', 'credit');
      return txnResult;
    });

    scheduleBackup(DB_PATH);
    welcomeEmail(newUser).catch(() => {});

    const token = signLearnerToken(newUser);
    res.status(201).json({ token, user: sanitizeUser(newUser) });
  } catch (err) {
    console.error('[auth/register]', err);
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// POST /api/auth/login — { email, password }
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });

    const db = readDb();
    const user = db.users.find(u => u.email.toLowerCase() === String(email).toLowerCase());
    if (!user) return res.status(401).json({ error: 'Invalid email or password.' });
    if (user.suspended) return res.status(403).json({ error: 'This account has been suspended. Contact the institute.' });

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) return res.status(401).json({ error: 'Invalid email or password.' });

    await mutate((dbInner) => {
      const u = dbInner.users.find(x => x.id === user.id);
      logActivity(dbInner, user.id, 'login', '');
    });

    const token = signLearnerToken(user);
    res.json({ token, user: sanitizeUser(user) });
  } catch (err) {
    console.error('[auth/login]', err);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// POST /api/auth/admin-login — { passcode }
router.post('/admin-login', (req, res) => {
  const { passcode } = req.body;
  if (!passcode || passcode.trim().toUpperCase() !== ADMIN_PASSCODE.toUpperCase()) {
    return res.status(401).json({ error: 'Incorrect admin passcode.' });
  }
  const token = signAdminToken();
  res.json({ token });
});

// GET /api/auth/me — current learner profile
router.get('/me', requireLearner, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
