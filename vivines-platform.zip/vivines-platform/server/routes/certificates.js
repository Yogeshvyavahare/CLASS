// server/routes/certificates.js
const express = require('express');
const path = require('path');
const fs = require('fs');

const { UNITS, CERTIFICATE_PRICING } = require('../data/content');
const { requireLearner } = require('../middleware/auth');
const { mutate, readDb, nextId, DB_PATH } = require('../db');
const { logActivity, applyWingsTransaction, sanitizeUser } = require('../utils/helpers');
const { certificateIssuedEmail } = require('../utils/email');
const { generateCertificatePdf } = require('../utils/certificate');
const { scheduleBackup } = require('../utils/driveBackup');

const router = express.Router();

const UPLOAD_DIR = path.join(__dirname, '..', 'data', 'uploads');
const ASSETS_DIR = path.join(__dirname, '..', '..', 'public', 'assets');

const CATEGORIES = [...new Set(UNITS.map(u => u.category))];
const MAIN_TRACK_CATEGORIES = CATEGORIES.filter(c => c !== 'Soft Skills & Employability');

function unitsInCategory(category) {
  return UNITS.filter(u => u.category === category).map(u => u.id);
}

function isCategoryComplete(learner, category) {
  const ids = unitsInCategory(category);
  return ids.length > 0 && ids.every(id => learner.completedUnits.includes(id));
}

function isFullProgrammeComplete(learner) {
  return MAIN_TRACK_CATEGORIES.every(cat => isCategoryComplete(learner, cat));
}

// GET /api/certificates — eligibility status for every claimable certificate
// plus the learner's already-claimed certificates
router.get('/', requireLearner, (req, res) => {
  const db = readDb();
  const learner = db.users.find(u => u.id === req.userId);

  const eligibility = CATEGORIES.map(cat => ({
    category: cat,
    complete: isCategoryComplete(learner, cat),
    claimed: learner.claimedCertificates.includes(cat),
    wingsCost: CERTIFICATE_PRICING[cat] ?? 15
  }));
  eligibility.push({
    category: 'FULL_PROGRAMME',
    label: 'Full Programme (Master Certificate)',
    complete: isFullProgrammeComplete(learner),
    claimed: learner.claimedCertificates.includes('FULL_PROGRAMME'),
    wingsCost: CERTIFICATE_PRICING.FULL_PROGRAMME ?? 40
  });

  const claimedRecords = db.certificates.filter(c => c.userId === req.userId);

  res.json({ eligibility, certificates: claimedRecords });
});

// POST /api/certificates/claim — { category }
router.post('/claim', requireLearner, async (req, res) => {
  const { category } = req.body;
  if (!category) return res.status(400).json({ error: 'Category is required.' });

  const isFull = category === 'FULL_PROGRAMME';
  if (!isFull && !CATEGORIES.includes(category)) {
    return res.status(400).json({ error: 'Unknown category.' });
  }

  const db = readDb();
  const learner = db.users.find(u => u.id === req.userId);

  if (learner.claimedCertificates.includes(category)) {
    return res.status(409).json({ error: 'You have already claimed this certificate.' });
  }

  const complete = isFull ? isFullProgrammeComplete(learner) : isCategoryComplete(learner, category);
  if (!complete) {
    return res.status(403).json({ error: 'Complete every unit assessment in this category before claiming its certificate.' });
  }

  const cost = CERTIFICATE_PRICING[category] ?? (isFull ? 40 : 15);

  let txnResult;
  await mutate((dbInner) => {
    const user = dbInner.users.find(u => u.id === req.userId);
    txnResult = applyWingsTransaction(dbInner, req.userId, -cost, `Certificate claimed: ${category}`, 'debit');
  });

  if (!txnResult.ok) {
    return res.status(402).json({ error: `You need ${cost} Wings to claim this certificate. Current balance: ${txnResult.balance}.` });
  }

  scheduleBackup(DB_PATH);

  // Generate the PDF outside the mutation lock (file I/O, not db I/O)
  const certificateId = nextId('cert');
  const label = isFull ? 'Full Programme (Master Certificate)' : category;
  const photoPath = learner.photoFile ? path.join(UPLOAD_DIR, learner.photoFile) : null;
  const logoPath = path.join(ASSETS_DIR, 'vivines-logo.png');

  let pdfResult;
  try {
    pdfResult = await generateCertificatePdf({
      certificateId,
      learnerName: learner.fullName,
      categoryLabel: label,
      issuedAtISO: new Date().toISOString(),
      photoPath,
      logoPath
    });
  } catch (err) {
    console.error('[certificates/claim] PDF generation failed:', err);
    // Refund the Wings since the certificate could not actually be produced
    await mutate((dbInner) => {
      applyWingsTransaction(dbInner, req.userId, cost, `Refund: certificate generation failed (${category})`, 'credit');
    });
    return res.status(500).json({ error: 'Certificate generation failed. Your Wings have been refunded — please try again.' });
  }

  const record = {
    id: certificateId,
    userId: req.userId,
    category,
    label,
    fileName: pdfResult.fileName,
    issuedAt: new Date().toISOString(),
    wingsCost: cost
  };

  await mutate((dbInner) => {
    const user = dbInner.users.find(u => u.id === req.userId);
    user.claimedCertificates.push(category);
    dbInner.certificates.push(record);
    logActivity(dbInner, req.userId, 'certificate_claimed', label);
  });

  scheduleBackup(DB_PATH);
  certificateIssuedEmail(learner, label).catch(() => {});

  const finalDb = readDb();
  const finalUser = finalDb.users.find(u => u.id === req.userId);

  res.status(201).json({ certificate: record, wings: finalUser.wings, user: sanitizeUser(finalUser) });
});

// GET /api/certificates/:id/download — secure, learner-scoped PDF download
router.get('/:id/download', requireLearner, (req, res) => {
  const db = readDb();
  const record = db.certificates.find(c => c.id === req.params.id);
  if (!record) return res.status(404).json({ error: 'Certificate not found.' });
  if (record.userId !== req.userId) return res.status(403).json({ error: 'Not authorized to access this certificate.' });

  const filePath = path.join(__dirname, '..', 'data', 'certificates', record.fileName);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Certificate file missing on server.' });

  res.download(filePath, `Vivines-Certificate-${record.category}.pdf`);
});

module.exports = router;
