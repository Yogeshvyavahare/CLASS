// server/routes/quiz.js
// Server-side quiz grading. Correct answers are read from server/data/content.js
// and NEVER sent to the client at any point before or after submission —
// the client only ever receives its own score.

const express = require('express');
const { UNITS } = require('../data/content');
const { requireLearner } = require('../middleware/auth');
const { mutate, DB_PATH } = require('../db');
const { logActivity } = require('../utils/helpers');
const { scheduleBackup } = require('../utils/driveBackup');

const router = express.Router();

const PASS_THRESHOLD = 5; // out of 7 questions per unit (~71%)

// POST /api/units/:id/submit — { answers: { [questionId]: selectedIndex } }
router.post('/:id/submit', requireLearner, async (req, res) => {
  const unit = UNITS.find(u => u.id === req.params.id);
  if (!unit) return res.status(404).json({ error: 'Unit not found.' });

  if (!req.user.unlockedUnits.includes(unit.id)) {
    return res.status(403).json({ error: 'Unlock this unit before attempting its assessment.' });
  }

  const answers = req.body.answers || {};
  if (typeof answers !== 'object') {
    return res.status(400).json({ error: 'Invalid answers payload.' });
  }

  let correctCount = 0;
  const breakdown = unit.questions.map(q => {
    const selected = answers[q.id];
    const isCorrect = Number(selected) === q.correctIndex;
    if (isCorrect) correctCount++;
    return { questionId: q.id, correct: isCorrect };
  });

  const total = unit.questions.length;
  const passed = correctCount >= PASS_THRESHOLD;
  const attempt = { score: correctCount, total, passed, at: new Date().toISOString() };

  await mutate((db) => {
    const user = db.users.find(u => u.id === req.userId);
    if (!user.quizAttempts[unit.id]) user.quizAttempts[unit.id] = [];
    user.quizAttempts[unit.id].push(attempt);
    if (passed && !user.completedUnits.includes(unit.id)) {
      user.completedUnits.push(unit.id);
    }
    logActivity(db, req.userId, passed ? 'unit_passed' : 'unit_attempt_failed', `${unit.title}: ${correctCount}/${total}`);
  });

  scheduleBackup(DB_PATH);

  res.json({ score: correctCount, total, passed, threshold: PASS_THRESHOLD, breakdown });
});

module.exports = router;
