// server/routes/jobs.js
const express = require('express');
const { requireLearner } = require('../middleware/auth');
const { mutate, readDb, nextId, DB_PATH } = require('../db');
const { logActivity } = require('../utils/helpers');
const { scheduleBackup } = require('../utils/driveBackup');

const router = express.Router();

// GET /api/jobs — career board, unlocked once the learner holds at least one certificate
router.get('/', requireLearner, (req, res) => {
  const db = readDb();
  const learner = db.users.find(u => u.id === req.userId);
  const unlocked = learner.claimedCertificates.length > 0;

  if (!unlocked) {
    return res.json({ unlocked: false, roles: [], message: 'Complete and claim at least one certificate to unlock the Career Opportunities board.' });
  }

  const roles = db.jobRoles.filter(r => r.active);
  const myApplications = db.jobApplications.filter(a => a.userId === req.userId);
  res.json({ unlocked: true, roles, myApplications });
});

// POST /api/jobs/:id/apply — { coverMessage }
router.post('/:id/apply', requireLearner, async (req, res) => {
  const db = readDb();
  const learner = db.users.find(u => u.id === req.userId);
  if (learner.claimedCertificates.length === 0) {
    return res.status(403).json({ error: 'Claim at least one certificate to unlock job applications.' });
  }

  const role = db.jobRoles.find(r => r.id === req.params.id && r.active);
  if (!role) return res.status(404).json({ error: 'Job role not found or no longer active.' });

  const alreadyApplied = db.jobApplications.find(a => a.userId === req.userId && a.roleId === role.id);
  if (alreadyApplied) return res.status(409).json({ error: 'You have already applied to this role.' });

  const application = {
    id: nextId('app'),
    userId: req.userId,
    roleId: role.id,
    roleTitle: role.title,
    coverMessage: req.body.coverMessage || '',
    status: 'submitted', // submitted -> reviewed -> shortlisted -> rejected/hired (admin-managed)
    submittedAt: new Date().toISOString()
  };

  await mutate((dbInner) => {
    dbInner.jobApplications.push(application);
    logActivity(dbInner, req.userId, 'job_application_submitted', role.title);
  });

  scheduleBackup(DB_PATH);
  res.status(201).json({ application });
});

module.exports = router;
