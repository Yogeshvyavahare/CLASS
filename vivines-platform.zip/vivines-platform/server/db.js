// server/db.js
// Minimal JSON-file database with atomic writes. No external DB required —
// keeps the whole platform zero-config for a small institute's scale.
// Atomicity: every write goes to a temp file first, then a rename, so a
// crash mid-write can never leave db.json truncated or corrupted.

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data', 'db.json');

const EMPTY_DB = {
  users: [],          // learners
  jobRoles: [],        // seeded from data/jobRoles.js on first run
  jobApplications: [],
  consultations: [],
  transactions: [],    // wings ledger: { id, userId, type, amount, balanceAfter, reason, at }
  certificates: [],
  activityLog: [],     // { id, userId, action, detail, at }
  meta: { seededAt: null, version: 1 }
};

let writeQueue = Promise.resolve();

function ensureDbFile() {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify(EMPTY_DB, null, 2), 'utf8');
  }
}

function readDb() {
  ensureDbFile();
  const raw = fs.readFileSync(DB_PATH, 'utf8');
  try {
    return JSON.parse(raw);
  } catch (err) {
    console.error('[db] db.json is corrupted, restoring from .bak if present:', err.message);
    const bakPath = DB_PATH + '.bak';
    if (fs.existsSync(bakPath)) {
      return JSON.parse(fs.readFileSync(bakPath, 'utf8'));
    }
    return JSON.parse(JSON.stringify(EMPTY_DB));
  }
}

// Atomic write: write to temp file, fsync, rename over the real file.
// Also keeps a rolling .bak of the previous good state.
function writeDbSync(data) {
  ensureDbFile();
  const tmpPath = DB_PATH + '.tmp';
  const bakPath = DB_PATH + '.bak';

  if (fs.existsSync(DB_PATH)) {
    fs.copyFileSync(DB_PATH, bakPath);
  }

  const fd = fs.openSync(tmpPath, 'w');
  fs.writeSync(fd, JSON.stringify(data, null, 2));
  fs.fsyncSync(fd);
  fs.closeSync(fd);
  fs.renameSync(tmpPath, DB_PATH);
}

// All mutations go through this so concurrent requests never interleave
// writes (Node is single-threaded per tick, but this also serializes any
// async work — like the optional Drive backup — around each mutation).
function mutate(updaterFn) {
  writeQueue = writeQueue.then(async () => {
    const db = readDb();
    const result = await updaterFn(db);
    writeDbSync(db);
    return result;
  });
  return writeQueue;
}

function nextId(prefix) {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

module.exports = { readDb, writeDbSync, mutate, nextId, DB_PATH, EMPTY_DB };
